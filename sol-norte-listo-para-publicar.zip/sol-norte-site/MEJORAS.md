# Sol Norte — mejoras aplicadas

## Interfaz y experiencia
- Se refinó la jerarquía visual del HUD con superficies translúcidas, mejor contraste y espaciado adaptable.
- Se ajustaron el minimapa, los indicadores y el panel de misión para pantallas pequeñas.
- Se mejoraron los estados hover/active, el feedback táctil y los focos visibles de teclado.
- Se optimizó el menú inicial para móviles y pantallas apaisadas; el CTA ahora está en español.
- Los paneles de pausa admiten desplazamiento en pantallas de poca altura.
- Se añadió un mensaje de recuperación si WebGL no puede iniciar el juego.
- Se respetan las preferencias de movimiento reducido en las transiciones nuevas.

## Controles y robustez
- Los controles mantenidos se liberan al perder el foco o al ocultar la pestaña, evitando que el personaje o el vehículo sigan moviéndose al volver.
- Se limpian los estados de joystick, teclado, acciones y botones mantenidos al perder foco.
- Se retira también el listener de menú contextual al destruir el controlador de entrada.
- Los botones táctiles liberan la acción al cancelar el gesto, perder la captura del puntero o perder el foco.

## Validación
- `npm test`: 189 pruebas pasaron y 8 fallaron en pruebas del inyector de metadatos OG/PWA (`scripts/grok-pwa-plugin.test.mjs`), fuera de los archivos modificados.
- `npm run typecheck` y el build no pudieron completarse porque las dependencias no quedaron instaladas en este entorno (los intentos de `npm ci` agotaron el tiempo); TypeScript reportó la ausencia de `@types/node` y `vite/client`.
- No se modificó la lógica central de misiones, economía, ciudad ni físicas del juego.
