# Publicar Sol Norte en Internet

Esta carpeta contiene el proyecto web completo de **Sol Norte**. La aplicación ya tiene configurado el adaptador de despliegue de Vercel (`nitro` con preset `vercel`) y el archivo `vercel.json`.

## Opción recomendada: GitHub + Vercel

Necesitas una cuenta gratuita de GitHub y otra de Vercel. No compartas contraseñas ni claves privadas con nadie.

### 1. Subir el proyecto a GitHub

1. Entra en https://github.com y crea una cuenta o inicia sesión.
2. Pulsa **New repository** y ponle `sol-norte`.
3. Puedes dejarlo en **Private**.
4. Sube el contenido de esta carpeta al repositorio (no subas `node_modules`, si existiera).

### 2. Publicarlo en Vercel

1. Entra en https://vercel.com y elige **Continue with GitHub**.
2. Pulsa **Add New → Project**.
3. Importa el repositorio `sol-norte`.
4. Deja el framework en **Other** o permite que Vercel detecte Vite/Nitro.
5. Usa estos valores si Vercel solicita configuración:
   - Install Command: `npm install --omit=dev --no-audit --no-fund`
   - Build Command: `npm run build`
   - Output Directory: dejar vacío / automático (Nitro genera la salida de Vercel).
6. Pulsa **Deploy** y espera a que termine.

### 3. Abrir el juego

Cuando Vercel termine, mostrará una dirección `https://...vercel.app`. Ábrela en Chrome. Esa será la dirección pública del juego y podrás compartirla.

## Importante

- Este proyecto usa renderizado de servidor y el adaptador Nitro para Vercel; no es una carpeta estática que se pueda publicar simplemente arrastrando el ZIP a un servicio de páginas estáticas.
- No se ha publicado automáticamente desde este entorno. Para obtener una dirección real, debes conectar el repositorio a tu cuenta de Vercel y pulsar **Deploy**.
- Si Vercel muestra un error, copia el texto del error (sin secretos ni tokens) y úsalo para corregir la configuración.
- El APK Android puede prepararse después de tener la URL HTTPS estable del juego.
