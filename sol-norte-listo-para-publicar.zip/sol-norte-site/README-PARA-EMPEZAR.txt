SOL NORTE — PROYECTO WEB

Para poner el juego en Internet, sigue los pasos del archivo:
PUBLICAR-EN-INTERNET.md

Resumen:
1) Crea un repositorio en https://github.com
2) Sube a él el contenido de esta carpeta.
3) Conecta ese repositorio en https://vercel.com
4) Pulsa Deploy.
5) Abre la dirección .vercel.app que te entregue Vercel.

El juego todavía no está publicado. La dirección pública solo existirá después del despliegue desde tu cuenta.
