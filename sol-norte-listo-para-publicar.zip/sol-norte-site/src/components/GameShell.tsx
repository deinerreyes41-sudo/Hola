import { useLayoutEffect, useRef, useState } from "react";
import { Crosshair, Flag, Pause, Radio, Star } from "lucide-react";
import { startGame, type GameApi } from "@/game/engine";
import { INITIAL_HUD, MISSIONS, type Hud } from "@/game/types";

function pesos(n: number) {
  return "$" + Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function Stick({ onStick }: { onStick: (x: number, y: number) => void }) {
  const knobRef = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);

  function place(el: HTMLDivElement, clientX: number, clientY: number) {
    const r = el.getBoundingClientRect();
    const dx = clientX - (r.left + r.width / 2);
    const dy = clientY - (r.top + r.height / 2);
    const max = r.width * 0.34;
    const mag = Math.hypot(dx, dy) || 1;
    const k = Math.min(max, mag);
    const nx = (dx / mag) * k;
    const ny = (dy / mag) * k;
    if (knobRef.current) knobRef.current.style.transform = `translate(${nx}px, ${ny}px)`;
    onStick(nx / max, -ny / max);
  }

  function reset() {
    pid.current = null;
    if (knobRef.current) knobRef.current.style.transform = "translate(0px, 0px)";
    onStick(0, 0);
  }

  return (
    <div
      className="sn-stick"
      role="group"
      aria-label="Joystick virtual: arrastra para moverte"
      onPointerDown={(e) => {
        pid.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        place(e.currentTarget, e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (pid.current !== e.pointerId) return;
        place(e.currentTarget, e.clientX, e.clientY);
      }}
      onPointerUp={reset}
      onPointerCancel={reset}
      onLostPointerCapture={reset}
    >
      <div ref={knobRef} className="sn-knob" />
    </div>
  );
}

function Pad({
  label,
  fire,
  onDown,
  onUp,
}: {
  label: string;
  fire?: boolean;
  onDown: () => void;
  onUp: () => void;
}) {
  return (
    <button
      type="button"
      className={fire ? "sn-pad is-fire" : "sn-pad"}
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        onDown();
      }}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      onLostPointerCapture={onUp}
      onBlur={onUp}
    >
      {label}
    </button>
  );
}

export function GameShell() {
  const viewRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<HTMLCanvasElement>(null);
  const apiRef = useRef<GameApi | null>(null);
  const [hud, setHud] = useState<Hud>(INITIAL_HUD);
  const [bootError, setBootError] = useState(false);

  useLayoutEffect(() => {
    const view = viewRef.current;
    const map = mapRef.current;
    if (!view || !map) return;
    let dead = false;
    let api: GameApi | null = null;
    try {
      api = startGame(view, map, (next) => {
        if (!dead) setHud(next);
      });
      apiRef.current = api;
    } catch (err) {
      console.error("No se pudo iniciar Sol Norte:", err);
      setBootError(true);
    }
    return () => {
      dead = true;
      api?.stop();
      apiRef.current = null;
    };
  }, []);

  const hold = (name: "attack" | "handbrake" | "interact" | "radio" | "pause", down: boolean) => {
    apiRef.current?.setHold(name, down);
  };

  return (
    <div className={hud.low && hud.phase === "play" ? "sn-root is-low" : "sn-root"}>
      <div ref={viewRef} className="sn-view" aria-label="Vista del mundo de Sol Norte" />
      {bootError && (
        <div className="sn-overlay" role="alert">
          <div className="sn-card">
            <p className="sn-kicker">Problema al iniciar</p>
            <h2>No pudimos cargar la ciudad</h2>
            <p>Tu navegador puede no ser compatible con WebGL. Prueba actualizarlo o abrir el juego en otro navegador.</p>
            <button type="button" className="is-primary" onClick={() => window.location.reload()}>Reintentar</button>
          </div>
        </div>
      )}
      <div className="sn-vignette" />

      <header className={hud.phase === "menu" ? "sn-hud is-off" : "sn-hud"}>
          <div className="sn-stack">
            <div className="sn-row">
              <button
                type="button"
                className="sn-pause-btn"
                aria-label="Pausa"
                onClick={() => apiRef.current?.togglePause()}
              >
                <Pause />
              </button>
              <div className="sn-chip sn-money">{pesos(hud.money)}</div>
              <div className="sn-chip">
                <div className="sn-health" aria-label="Salud">
                  <span style={{ width: `${hud.health}%` }} />
                </div>
              </div>
              <div className={hud.stars > 0 ? "sn-chip sn-stars is-hot" : "sn-chip sn-stars"} aria-label="Buscado">
                {[0, 1, 2, 3].map((i) => (
                  <Star key={i} className={i < hud.stars ? "sn-star is-on" : "sn-star"} />
                ))}
              </div>
            </div>
            <div className="sn-mission">
              <small>
                {hud.district} · {hud.clock} · {hud.radio}
              </small>
              <strong>{hud.missionTitle || "Libre"}</strong>
              <p>{hud.missionText}</p>
            </div>
          </div>
          <div className="sn-map-wrap">
            <canvas ref={mapRef} className="sn-map" width={192} height={192} />
          </div>
        </header>

      {hud.phase === "play" && hud.showArrow && (
        <div className="sn-arrow">
          <i style={{ transform: `rotate(${hud.arrow}rad)` }} />
          <span>{hud.dist} m</span>
        </div>
      )}

      {hud.phase === "play" && hud.toast && <div className="sn-toast">{hud.toast}</div>}

      {hud.phase === "play" && hud.inCar && (
        <div className="sn-speed">
          <b>{hud.speedKmh}</b>
          <span>km/h · {hud.carName}</span>
        </div>
      )}

      {hud.phase === "play" && (
        <div className="sn-weapon">
          {hud.pistol ? <Crosshair /> : <Flag />}
          <div>
            <b>{hud.weapon}</b>
            <span>{hud.pistol ? `${hud.ammo} balas` : "cuerpo a cuerpo"}</span>
          </div>
        </div>
      )}

      {hud.phase === "play" && (
        <div className="sn-touch">
          <Stick onStick={(x, y) => apiRef.current?.setStick(x, y)} />
          <div className="sn-actions">
            <Pad label={hud.inCar ? "Bajar" : "Subir"} onDown={() => hold("interact", true)} onUp={() => hold("interact", false)} />
            <Pad fire label={hud.pistol ? "Disparo" : "Golpe"} onDown={() => hold("attack", true)} onUp={() => hold("attack", false)} />
            <Pad label="Freno" onDown={() => hold("handbrake", true)} onUp={() => hold("handbrake", false)} />
            <Pad label="Radio" onDown={() => hold("radio", true)} onUp={() => hold("radio", false)} />
          </div>
        </div>
      )}

      {hud.phase === "menu" && (
        <section className="sn-menu">
          <p className="sn-kicker">Puerto del Sol</p>
          <h1 className="sn-title">
            Sol
            <span>Norte</span>
          </h1>
          <p className="sn-lead">
            Ciudad abierta al atardecer. Camina, súbete a lo que esté en la calle y cumple el encargo antes de que
            la patrulla te alcance.
          </p>
          <button type="button" className="sn-start" onClick={() => apiRef.current?.start()}>
            Jugar ahora <span aria-hidden="true">↗</span>
          </button>
          <p className="sn-meta">
            {pesos(hud.money)} · {hud.done.length}/4 encargos
          </p>
          <ul className="sn-hints">
            <li>
              <kbd>W</kbd>
              <kbd>A</kbd>
              <kbd>S</kbd>
              <kbd>D</kbd> mover
            </li>
            <li>
              <kbd>E</kbd> subir o bajar
            </li>
            <li>
              <kbd>Espacio</kbd> golpear
            </li>
            <li>
              <kbd>Shift</kbd> correr o frenar
            </li>
            <li>
              <kbd>R</kbd> <Radio className="sn-star" /> radio
            </li>
            <li>
              <kbd>Esc</kbd> pausa
            </li>
          </ul>
        </section>
      )}

      {hud.phase === "pause" && (
        <div className="sn-overlay">
          <div className="sn-card">
            <p className="sn-kicker">Pausa</p>
            <h2>Puerto del Sol</h2>
            <p>
              {pesos(hud.money)} en el bolsillo. Elige un encargo o sigue suelto por la ciudad.
            </p>
            <button type="button" className="is-primary" onClick={() => apiRef.current?.togglePause()}>
              Seguir
            </button>
            {MISSIONS.map((m) => {
              const isDone = hud.done.includes(m.id);
              const isActive = hud.active === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  className={isDone ? "is-done" : undefined}
                  onClick={() => apiRef.current?.beginMission(m.id)}
                >
                  {m.title}
                  {isActive ? " · activo" : ""}
                  {isDone ? " · hecho" : ""}
                  <small>
                    {m.brief} · {pesos(m.reward)}
                  </small>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {hud.phase === "dead" && (
        <div className="sn-overlay">
          <div className="sn-card">
            <p className="sn-kicker">Clínica</p>
            <h2>{hud.deadTitle || "Te caíste"}</h2>
            <p>{hud.deadText}</p>
            <button type="button" className="is-primary" onClick={() => apiRef.current?.respawn()}>
              Reaparecer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
