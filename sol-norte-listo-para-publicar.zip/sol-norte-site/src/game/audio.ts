export function createAudio() {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let music: GainNode | null = null;
  let engine: OscillatorNode | null = null;
  let engineGain: GainNode | null = null;
  let siren: OscillatorNode | null = null;
  let sirenGain: GainNode | null = null;
  let station = 0;
  let next = 0;
  let step = 0;

  function ensure() {
    if (ctx) return;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    ctx = new Ctx();
    master = ctx.createGain();
    master.gain.value = 0.22;
    master.connect(ctx.destination);
    music = ctx.createGain();
    music.gain.value = 0.7;
    music.connect(master);
    engine = ctx.createOscillator();
    engine.type = "sawtooth";
    engine.frequency.value = 50;
    engineGain = ctx.createGain();
    engineGain.gain.value = 0;
    engine.connect(engineGain);
    engineGain.connect(master);
    engine.start();
    siren = ctx.createOscillator();
    siren.type = "square";
    siren.frequency.value = 680;
    sirenGain = ctx.createGain();
    sirenGain.gain.value = 0;
    siren.connect(sirenGain);
    sirenGain.connect(master);
    siren.start();
    next = ctx.currentTime;
  }

  function tone(freq: number, at: number, dur: number, type: OscillatorType, gain: number) {
    if (!ctx || !music) return;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, at);
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(gain, at + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    osc.connect(g);
    g.connect(music);
    osc.start(at);
    osc.stop(at + dur + 0.02);
  }

  function noise(at: number, dur: number, gain: number) {
    if (!ctx || !music) return;
    const n = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, n, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 180;
    g.gain.setValueAtTime(gain, at);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(music);
    src.start(at);
  }

  return {
    unlock() {
      try {
        ensure();
        void ctx?.resume();
      } catch {
        /* autoplay locks are fine until the next gesture */
      }
    },
    setStation(n: number) {
      station = n;
      if (ctx) next = ctx.currentTime;
      step = 0;
    },
    get station() {
      return station;
    },
    tick(speed: number, driving: boolean, sirenOn: boolean) {
      if (!ctx || !engine || !engineGain || !siren || !sirenGain) return;
      const now = ctx.currentTime;
      engine.frequency.setTargetAtTime(48 + speed * 3.1, now, 0.08);
      engineGain.gain.setTargetAtTime(driving ? Math.min(0.045, 0.012 + speed * 0.001) : 0, now, 0.1);
      const wobble = 640 + Math.sin(now * 9) * 180;
      siren.frequency.setTargetAtTime(wobble, now, 0.05);
      sirenGain.gain.setTargetAtTime(sirenOn ? 0.03 : 0, now, 0.1);
      if (station === 0 || !music) return;
      if (next < now - 0.5) next = now;
      const beat = station === 1 ? 0.29 : 0.21;
      const scale = station === 1 ? [110, 146.8, 164.8, 196, 146.8] : [98, 123.5, 146.8, 174.6, 130.8];
      while (next < now + 0.35) {
        const note = scale[step % scale.length] ?? 110;
        if (station === 1) {
          if (step % 2 === 0) noise(next, 0.09, 0.35);
          tone(note, next, 0.22, "triangle", 0.18);
          if (step % 4 === 2) tone(note * 2, next, 0.12, "square", 0.05);
        } else {
          if (step % 4 === 0) noise(next, 0.08, 0.28);
          tone(note / 2, next, 0.28, "sawtooth", 0.07);
          tone(note * 2, next + 0.05, 0.1, "square", 0.04);
        }
        step = (step + 1) % 16;
        next += beat;
      }
    },
    blip() {
      if (!ctx || !master) return;
      toneNode(ctx, master, 660, 0.07, "square", 0.08);
    },
    cash() {
      if (!ctx || !master) return;
      toneNode(ctx, master, 880, 0.08, "square", 0.07);
      toneNode(ctx, master, 1320, 0.1, "square", 0.05);
    },
    hit() {
      if (!ctx || !master) return;
      toneNode(ctx, master, 140, 0.12, "sawtooth", 0.08);
    },
    shot() {
      if (!ctx || !master) return;
      toneNode(ctx, master, 220, 0.07, "square", 0.06);
    },
    swing() {
      if (!ctx || !master) return;
      toneNode(ctx, master, 180, 0.06, "sawtooth", 0.04);
    },
    dispose() {
      void ctx?.close();
      ctx = null;
    },
  };
}

function toneNode(
  ctx: AudioContext,
  dest: AudioNode,
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
) {
  const t = ctx.currentTime;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(g);
  g.connect(dest);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
