export const BLOCKS = 7;
export const BLOCK = 26;
export const ROAD = 12;
export const STRIDE = BLOCK + ROAD;
export const MAP = BLOCKS * STRIDE + ROAD;
export const ORIGIN = -MAP / 2;

export type District = "centro" | "playa" | "barrio" | "industrial" | "parque";

export const DISTRICT_NAME: Record<District, string> = {
  centro: "Centro",
  playa: "Playa Dorada",
  barrio: "Barrio Alto",
  industrial: "Zona Férrea",
  parque: "Parque Central",
};

export type Aabb = { minX: number; maxX: number; minZ: number; maxZ: number; h: number };

export type Building = Aabb & {
  color: number;
  roof: number;
  landmark?: "hospital" | "safehouse" | "armeria";
};

export type PropKind = "tree" | "palm" | "lamp" | "umbrella";

export type Prop = {
  kind: PropKind;
  x: number;
  z: number;
  rot: number;
  color: number;
};

export type Spot = { x: number; z: number };

export type City = {
  buildings: Building[];
  blockers: Aabb[];
  props: Prop[];
  spots: {
    spawn: Spot;
    park: Spot;
    dock: Spot;
    hideout: Spot;
    safehouse: Spot;
    contact: Spot;
    armeria: Spot;
    hospital: Spot;
    race: Spot[];
    cash: Spot[];
    meds: Spot[];
  };
};

export function roadX(i: number): number {
  return ORIGIN + i * STRIDE + ROAD / 2;
}

export function roadZ(k: number): number {
  return ORIGIN + k * STRIDE + ROAD / 2;
}

export function lotOf(i: number, k: number) {
  const x0 = ORIGIN + ROAD + i * STRIDE;
  const z0 = ORIGIN + ROAD + k * STRIDE;
  return { x0, z0, x1: x0 + BLOCK, z1: z0 + BLOCK, cx: x0 + BLOCK / 2, cz: z0 + BLOCK / 2 };
}

export function districtOf(i: number, k: number): District {
  if (i === 3 && k === 3) return "parque";
  if (k >= 5) return "playa";
  if (i <= 1 && k <= 2) return "industrial";
  if (i >= 5 && k <= 3) return "barrio";
  return "centro";
}

export function districtAt(x: number, z: number): District {
  let i = Math.floor((x - ORIGIN) / STRIDE);
  let k = Math.floor((z - ORIGIN) / STRIDE);
  i = Math.max(0, Math.min(BLOCKS - 1, i));
  k = Math.max(0, Math.min(BLOCKS - 1, k));
  return districtOf(i, k);
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PALETTE: Record<District, number[]> = {
  centro: [0xc4b6a4, 0xb7a898, 0x8e9aa8, 0xd9d3c7, 0x6f7c8a, 0xe4d8c8],
  playa: [0xf2d2a2, 0xef8f6b, 0x7ec8c3, 0xf6e27a, 0xf7f3ea, 0xe07a5f],
  barrio: [0xe07a5f, 0x81b29a, 0xf2cc8f, 0x3d405b, 0xe9c46a, 0xf4f1de],
  industrial: [0x8d9096, 0x5c6370, 0x6e7278, 0x4e555d],
  parque: [],
};

const ROOFS = [0xa8432f, 0x8c4034, 0x6e4b3a, 0x4a4038];

export function buildCity(): City {
  const buildings: Building[] = [];
  const props: Prop[] = [];

  for (let k = 0; k < BLOCKS; k++) {
    for (let i = 0; i < BLOCKS; i++) {
      const district = districtOf(i, k);
      const lot = lotOf(i, k);
      const rng = mulberry32(i * 9176 + k * 131 + 42);
      const inset = 2.55;
      const x0 = lot.x0 + inset;
      const z0 = lot.z0 + inset;
      const aw = BLOCK - inset * 2;
      const ad = BLOCK - inset * 2;

      if (district === "parque") {
        for (let t = 0; t < 10; t++) {
          const ang = (t / 10) * Math.PI * 2;
          props.push({
            kind: "tree",
            x: lot.cx + Math.cos(ang) * 8.5,
            z: lot.cz + Math.sin(ang) * 8.5,
            rot: rng() * 6,
            color: 0x2f6b3a,
          });
        }
        continue;
      }

      const made: Building[] = [];
      if (district === "industrial") {
        const w = aw * 0.82;
        const d = ad * 0.7;
        made.push({
          minX: x0 + (aw - w) / 2,
          maxX: x0 + (aw - w) / 2 + w,
          minZ: z0 + (ad - d) / 2,
          maxZ: z0 + (ad - d) / 2 + d,
          h: 8 + rng() * 6,
          color: PALETTE.industrial[Math.floor(rng() * PALETTE.industrial.length)] ?? 0x6e7278,
          roof: 0x3e4450,
        });
      } else {
        const cols = 2;
        const rows = 2;
        const gap = 1.15;
        const cw = (aw - gap) / cols;
        const cd = (ad - gap) / rows;
        const target = district === "playa" ? 2 : district === "centro" ? 3 : 3;
        let placed = 0;
        for (let r = 0; r < rows && placed < target; r++) {
          for (let c = 0; c < cols && placed < target; c++) {
            if (placed > 0 && rng() < 0.18) continue;
            const w = cw * (0.7 + rng() * 0.24);
            const d = cd * (0.7 + rng() * 0.24);
            const hx = x0 + c * (cw + gap) + (cw - w) / 2;
            const hz = z0 + r * (cd + gap) + (cd - d) / 2;
            let h = 8 + rng() * 10;
            if (district === "centro") h = 16 + rng() * 26;
            if (district === "playa") h = 4.5 + rng() * 7;
            if (district === "barrio") h = 6 + rng() * 11;
            if (district === "centro" && i === 3 && k === 2 && placed === 0) h = 58;
            if (district === "centro" && i === 4 && k === 4 && placed === 0) h = 46;
            const colors = PALETTE[district];
            made.push({
              minX: hx,
              maxX: hx + w,
              minZ: hz,
              maxZ: hz + d,
              h,
              color: colors[Math.floor(rng() * colors.length)] ?? 0xc4b6a4,
              roof: ROOFS[Math.floor(rng() * ROOFS.length)] ?? 0xa8432f,
            });
            placed++;
          }
        }
      }

      if (i === 2 && k === 2 && made[0]) made[0].landmark = "hospital";
      if (i === 1 && k === 1 && made[0]) made[0].landmark = "armeria";
      if (i === 5 && k === 1 && made[0]) made[0].landmark = "safehouse";
      buildings.push(...made);

      if (district === "playa") {
        props.push({
          kind: "palm",
          x: lot.x0 + 4,
          z: lot.z1 - 4,
          rot: rng() * 6,
          color: 0x2f8f4e,
        });
        if (rng() > 0.4) {
          props.push({
            kind: "palm",
            x: lot.x1 - 4.5,
            z: lot.z0 + 5,
            rot: rng() * 6,
            color: 0x247a40,
          });
        }
        props.push({
          kind: "umbrella",
          x: lot.cx + (rng() - 0.5) * 6,
          z: lot.cz + (rng() - 0.5) * 4,
          rot: rng() * 3,
          color: rng() > 0.5 ? 0xe07a5f : 0xf0b429,
        });
      } else if (rng() > 0.45) {
        props.push({
          kind: "tree",
          x: lot.x0 + 1.3,
          z: lot.cz,
          rot: rng() * 6,
          color: district === "barrio" ? 0x3e7a45 : 0x2c6a38,
        });
      }
    }
  }

  for (let i = 0; i <= BLOCKS; i++) {
    const edge = ORIGIN + i * STRIDE + ROAD + 0.7;
    for (let z = ORIGIN + 8; z < ORIGIN + MAP - 4; z += 24) {
      let near = false;
      for (let k = 0; k <= BLOCKS; k++) {
        if (Math.abs(z - roadZ(k)) < 7) near = true;
      }
      if (near) continue;
      props.push({ kind: "lamp", x: edge, z, rot: 0, color: 0xf0d090 });
    }
  }

  const park = lotOf(3, 3);
  const blockers: Aabb[] = [
    {
      minX: park.cx - 1.6,
      maxX: park.cx + 1.6,
      minZ: park.cz - 1.6,
      maxZ: park.cz + 1.6,
      h: 1.3,
    },
  ];

  const hosp = lotOf(2, 2);
  const safe = lotOf(5, 1);
  const guns = lotOf(1, 1);
  const contactLot = lotOf(2, 6);

  return {
    buildings,
    blockers,
    props,
    spots: {
      spawn: { x: roadX(3), z: roadZ(3) },
      park: { x: park.cx, z: park.cz },
      dock: { x: roadX(4), z: ORIGIN + MAP + 11 },
      hideout: { x: roadX(6) - 3.4, z: lotOf(5, 2).cz },
      safehouse: { x: roadX(5) + 3.4, z: safe.cz },
      contact: { x: roadX(2) + 3.4, z: contactLot.cz },
      armeria: { x: roadX(1) + 3.4, z: guns.cz },
      hospital: { x: roadX(2) + 3.4, z: hosp.cz },
      race: [
        { x: roadX(3), z: roadZ(4) },
        { x: roadX(5), z: roadZ(4) },
        { x: roadX(5), z: roadZ(6) },
        { x: roadX(2), z: roadZ(6) },
        { x: roadX(2), z: roadZ(3) },
      ],
      cash: [
        { x: roadX(5), z: roadZ(5) },
        { x: roadX(1), z: roadZ(6) },
        { x: roadX(6), z: roadZ(3) },
      ],
      meds: [
        { x: roadX(2) - 3.2, z: hosp.cz },
        { x: roadX(4), z: roadZ(1) },
      ],
    },
  };
}

export function paintGround(ctx: CanvasRenderingContext2D, size: number) {
  const toX = (x: number) => ((x - ORIGIN) / MAP) * size;
  const toY = (z: number) => ((z - ORIGIN) / MAP) * size;
  const rect = (x: number, z: number, w: number, d: number) => {
    ctx.fillRect(toX(x), toY(z), (w / MAP) * size, (d / MAP) * size);
  };

  const ground: Record<District, string> = {
    centro: "#b7aa98",
    playa: "#e4cf9e",
    barrio: "#c9a58c",
    industrial: "#8a877f",
    parque: "#6d8f56",
  };

  ctx.fillStyle = "#6d604e";
  ctx.fillRect(0, 0, size, size);

  for (let k = 0; k < BLOCKS; k++) {
    for (let i = 0; i < BLOCKS; i++) {
      const lot = lotOf(i, k);
      ctx.fillStyle = ground[districtOf(i, k)];
      rect(lot.x0, lot.z0, BLOCK, BLOCK);
    }
  }

  ctx.fillStyle = "#d7d1c4";
  const sw = 2.2;
  for (let k = 0; k < BLOCKS; k++) {
    for (let i = 0; i < BLOCKS; i++) {
      const lot = lotOf(i, k);
      rect(lot.x0, lot.z0, BLOCK, sw);
      rect(lot.x0, lot.z1 - sw, BLOCK, sw);
      rect(lot.x0, lot.z0, sw, BLOCK);
      rect(lot.x1 - sw, lot.z0, sw, BLOCK);
    }
  }

  ctx.fillStyle = "#3a3f46";
  for (let i = 0; i <= BLOCKS; i++) rect(ORIGIN + i * STRIDE, ORIGIN, ROAD, MAP);
  for (let k = 0; k <= BLOCKS; k++) rect(ORIGIN, ORIGIN + k * STRIDE, MAP, ROAD);

  ctx.fillStyle = "#efe6c8";
  const dash = 2.1;
  const gap = 2.4;
  for (let i = 0; i <= BLOCKS; i++) {
    const x = roadX(i) - 0.12;
    for (let z = ORIGIN + 1; z < ORIGIN + MAP; z += dash + gap) {
      let skip = false;
      for (let k = 0; k <= BLOCKS; k++) if (Math.abs(z - roadZ(k)) < ROAD * 0.48) skip = true;
      if (!skip) rect(x, z, 0.24, dash);
    }
  }
  for (let k = 0; k <= BLOCKS; k++) {
    const z = roadZ(k) - 0.12;
    for (let x = ORIGIN + 1; x < ORIGIN + MAP; x += dash + gap) {
      let skip = false;
      for (let i = 0; i <= BLOCKS; i++) if (Math.abs(x - roadX(i)) < ROAD * 0.48) skip = true;
      if (!skip) rect(x, z, dash, 0.24);
    }
  }

  ctx.fillStyle = "rgba(244,241,234,0.9)";
  for (let i = 0; i <= BLOCKS; i++) {
    for (let k = 0; k <= BLOCKS; k++) {
      const cx = roadX(i);
      const cz = roadZ(k);
      for (let s = -2; s <= 2; s++) {
        rect(cx - ROAD / 2 + 1.1, cz + s * 0.55 - 0.15, 2.3, 0.28);
        rect(cx + ROAD / 2 - 3.4, cz + s * 0.55 - 0.15, 2.3, 0.28);
      }
    }
  }

  const park = lotOf(3, 3);
  ctx.fillStyle = "#7ea365";
  ctx.beginPath();
  ctx.arc(toX(park.cx), toY(park.cz), (7 / MAP) * size, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#d7d1c4";
  ctx.beginPath();
  ctx.arc(toX(park.cx), toY(park.cz), (2.1 / MAP) * size, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#f3e6c4";
  rect(ORIGIN, ORIGIN + MAP - 2.4, MAP, 2.4);

  ctx.fillStyle = "rgba(48, 36, 24, 0.45)";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const labels: { i: number; k: number; text: string }[] = [
    { i: 3, k: 1, text: "CENTRO" },
    { i: 3, k: 3, text: "PARQUE" },
    { i: 3, k: 6, text: "PLAYA" },
    { i: 6, k: 1, text: "BARRIO" },
    { i: 0, k: 1, text: "FÉRREA" },
  ];
  ctx.font = `700 ${Math.floor(size / 42)}px sans-serif`;
  for (const label of labels) {
    const lot = lotOf(label.i, label.k);
    ctx.fillText(label.text, toX(lot.cx), toY(lot.cz));
  }
}

export function resolveCircle(
  x: number,
  z: number,
  radius: number,
  boxes: Aabb[],
): { x: number; z: number; hit: boolean } {
  let hit = false;
  for (let iter = 0; iter < 2; iter++) {
    for (const b of boxes) {
      const cx = Math.max(b.minX, Math.min(x, b.maxX));
      const cz = Math.max(b.minZ, Math.min(z, b.maxZ));
      let dx = x - cx;
      let dz = z - cz;
      const r2 = radius * radius;
      const d2 = dx * dx + dz * dz;
      if (d2 >= r2) continue;
      hit = true;
      if (d2 < 1e-8) {
        const left = x - b.minX;
        const right = b.maxX - x;
        const down = z - b.minZ;
        const up = b.maxZ - z;
        const m = Math.min(left, right, down, up);
        if (m === left) x = b.minX - radius;
        else if (m === right) x = b.maxX + radius;
        else if (m === down) z = b.minZ - radius;
        else z = b.maxZ + radius;
      } else {
        const d = Math.sqrt(d2);
        const push = radius - d;
        x += (dx / d) * push;
        z += (dz / d) * push;
      }
    }
  }

  const inset = 1.5;
  const minB = ORIGIN + inset;
  const maxB = ORIGIN + MAP - inset;
  const pierX = roadX(4);
  let maxZ = maxB;
  if (z > ORIGIN + MAP - 8 && Math.abs(x - pierX) < 5.2) {
    maxZ = ORIGIN + MAP + 16;
    if (x < pierX - 2.5) {
      x = pierX - 2.5;
      hit = true;
    }
    if (x > pierX + 2.5) {
      x = pierX + 2.5;
      hit = true;
    }
  }
  if (x < minB) {
    x = minB;
    hit = true;
  }
  if (x > maxB) {
    x = maxB;
    hit = true;
  }
  if (z < minB) {
    z = minB;
    hit = true;
  }
  if (z > maxZ) {
    z = maxZ;
    hit = true;
  }
  return { x, z, hit };
}
