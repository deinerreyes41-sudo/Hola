import * as THREE from "three";
import {
  BLOCK,
  BLOCKS,
  DISTRICT_NAME,
  MAP,
  ORIGIN,
  ROAD,
  STRIDE,
  type Building,
  type City,
  buildCity,
  districtAt,
  paintGround,
  resolveCircle,
  roadX,
  roadZ,
} from "./city";
import { createAudio } from "./audio";
import { createInput, type Holds } from "./input";
import { INITIAL_HUD, MISSIONS, type Hud, type MissionId } from "./types";

const STEP = 1 / 60;
const SAVE_KEY = "sol-norte-save-v1";

const SPECS = {
  sedan: { w: 1.7, h: 0.45, l: 4.05, vmax: 22, accel: 14, turn: 1.9, name: "Nube" },
  sports: { w: 1.85, h: 0.38, l: 4.25, vmax: 30, accel: 20, turn: 2.05, name: "Lince" },
  van: { w: 1.9, h: 0.78, l: 4.7, vmax: 16, accel: 10, turn: 1.45, name: "Toro" },
  pickup: { w: 1.8, h: 0.5, l: 4.5, vmax: 20, accel: 13, turn: 1.7, name: "Cerro" },
  taxi: { w: 1.7, h: 0.45, l: 4.15, vmax: 21, accel: 14, turn: 1.85, name: "Abeja" },
  cop: { w: 1.75, h: 0.48, l: 4.35, vmax: 26, accel: 17, turn: 1.95, name: "Patrulla" },
} as const;

type Kind = keyof typeof SPECS;

type Car = {
  id: string;
  kind: Kind;
  x: number;
  z: number;
  yaw: number;
  speed: number;
  ai: "traffic" | "parked" | "cop" | "player";
  axis: "x" | "z";
  dir: 1 | -1;
  lane: number;
  color: THREE.Color;
  hp: number;
};

type Ped = {
  x: number;
  z: number;
  yaw: number;
  state: "walk" | "down";
  downT: number;
  reported: boolean;
  points: { x: number; z: number }[];
  pi: number;
  speed: number;
  color: THREE.Color;
};

type Run = { id: MissionId; step: number; left: number };

export type GameApi = {
  start: () => void;
  togglePause: () => void;
  beginMission: (id: MissionId) => void;
  respawn: () => void;
  setStick: (x: number, y: number) => void;
  setHold: (name: keyof Holds, down: boolean) => void;
  stop: () => void;
};

const KINDS: Kind[] = ["sedan", "sports", "van", "pickup", "taxi", "cop"];
const CAP: Record<Kind, number> = { sedan: 8, sports: 3, van: 2, pickup: 4, taxi: 3, cop: 4 };

function mergeParts(parts: { geo: THREE.BufferGeometry; color: THREE.Color }[]) {
  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = [];
  for (const part of parts) {
    const geo = part.geo.index ? part.geo.toNonIndexed() : part.geo;
    const pos = geo.getAttribute("position");
    const nor = geo.getAttribute("normal");
    for (let i = 0; i < pos.count; i++) {
      positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      normals.push(nor.getX(i), nor.getY(i), nor.getZ(i));
      colors.push(part.color.r, part.color.g, part.color.b);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  g.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  return g;
}

function carGeometry(kind: Kind) {
  const s = SPECS[kind];
  const white = new THREE.Color(1, 1, 1);
  const glass = new THREE.Color(0.16, 0.22, 0.28);
  const tire = new THREE.Color(0.07, 0.07, 0.08);
  const light = new THREE.Color(1, 0.92, 0.55);
  const body = new THREE.BoxGeometry(s.w, s.h, s.l);
  body.translate(0, 0.34 + s.h / 2, 0);
  const cabH = kind === "van" ? s.h * 0.85 : s.h * 0.78;
  const cabL = kind === "van" ? s.l * 0.34 : s.l * 0.38;
  const cab = new THREE.BoxGeometry(s.w * 0.78, cabH, cabL);
  const cabZ = kind === "van" ? -s.l * 0.2 : -s.l * 0.06;
  cab.translate(0, 0.34 + s.h + cabH / 2 - 0.02, cabZ);
  const wheelGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.24, 8);
  wheelGeo.rotateZ(Math.PI / 2);
  const wheels: THREE.BufferGeometry[] = [];
  const wx = s.w * 0.42;
  const wz = s.l * 0.32;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const w = wheelGeo.clone();
      w.translate(sx * wx, 0.32, sz * wz);
      wheels.push(w);
    }
  }
  const lamp = new THREE.BoxGeometry(0.22, 0.12, 0.08);
  const hl1 = lamp.clone();
  const hl2 = lamp.clone();
  hl1.translate(-s.w * 0.28, 0.42 + s.h * 0.2, -s.l / 2 - 0.02);
  hl2.translate(s.w * 0.28, 0.42 + s.h * 0.2, -s.l / 2 - 0.02);
  const parts = [
    { geo: body, color: white },
    { geo: cab, color: glass },
    { geo: hl1, color: light },
    { geo: hl2, color: light },
    ...wheels.map((geo) => ({ geo, color: tire })),
  ];
  if (kind === "cop") {
    const bar = new THREE.BoxGeometry(s.w * 0.55, 0.12, 0.28);
    bar.translate(0, 0.34 + s.h + cabH + 0.08, cabZ);
    parts.push({ geo: bar, color: new THREE.Color(0.9, 0.15, 0.15) });
  }
  return mergeParts(parts);
}

function pedGeometry() {
  const shirt = new THREE.Color(1, 1, 1);
  const torso = new THREE.BoxGeometry(0.38, 0.5, 0.22);
  torso.translate(0, 1.15, 0);
  const head = new THREE.BoxGeometry(0.22, 0.22, 0.22);
  head.translate(0, 1.52, 0);
  const legs = new THREE.BoxGeometry(0.28, 0.46, 0.18);
  legs.translate(0, 0.68, 0);
  return mergeParts([
    { geo: torso, color: shirt },
    { geo: head, color: new THREE.Color(0.95, 0.78, 0.64) },
    { geo: legs, color: new THREE.Color(0.18, 0.2, 0.26) },
  ]);
}

function makeSign(text: string, bg: string, fg: string) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 96;
  const g = c.getContext("2d");
  if (!g) return new THREE.Mesh();
  g.fillStyle = bg;
  g.fillRect(0, 0, 256, 96);
  g.fillStyle = fg;
  g.font = "700 54px sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text, 128, 50);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(5.2, 1.95),
    new THREE.MeshLambertMaterial({ map: tex, side: THREE.DoubleSide }),
  );
  return mesh;
}

export function startGame(
  container: HTMLElement,
  mapCanvas: HTMLCanvasElement,
  onHud: (hud: Hud) => void,
): GameApi {
  const canvas = document.createElement("canvas");
  canvas.className = "sn-canvas";
  container.appendChild(canvas);
  const city: City = buildCity();
  const solids = [...city.buildings, ...city.blockers];
  const input = createInput(canvas);
  const audio = createAudio();
  const mapCtx = mapCanvas.getContext("2d");

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.06;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xf0a36a, 95, 340);
  scene.background = new THREE.Color(0xf0a36a);
  const camera = new THREE.PerspectiveCamera(66, 1, 0.12, 600);

  const hemi = new THREE.HemisphereLight(0xffe1c4, 0x3a3428, 1);
  const sun = new THREE.DirectionalLight(0xfff2dd, 1.2);
  sun.position.set(-80, 55, -36);
  scene.add(hemi, sun);

  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(460, 20, 12),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      vertexShader: `varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `varying vec3 vP; void main(){
        float h = normalize(vP).y;
        vec3 top = vec3(0.16, 0.34, 0.62);
        vec3 hor = vec3(0.95, 0.58, 0.30);
        vec3 bot = vec3(0.78, 0.38, 0.24);
        vec3 col = mix(hor, top, smoothstep(0.02, 0.55, h));
        col = mix(bot, col, smoothstep(-0.25, 0.08, h));
        gl_FragColor = vec4(col, 1.0);
      }`,
    }),
  );
  scene.add(sky);

  const sunBall = new THREE.Mesh(
    new THREE.SphereGeometry(10, 12, 10),
    new THREE.MeshBasicMaterial({ color: 0xffc56a, fog: false }),
  );
  sunBall.position.set(-120, 28, -70);
  scene.add(sunBall);

  const groundCanvas = document.createElement("canvas");
  groundCanvas.width = 2048;
  groundCanvas.height = 2048;
  const g2 = groundCanvas.getContext("2d");
  if (g2) paintGround(g2, 2048);
  const groundTex = new THREE.CanvasTexture(groundCanvas);
  groundTex.colorSpace = THREE.SRGBColorSpace;
  groundTex.anisotropy = 8;
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(MAP, MAP),
    new THREE.MeshLambertMaterial({ map: groundTex }),
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const waterUniforms = { uTime: { value: 0 } };
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(MAP + 100, 90, 28, 14),
    new THREE.ShaderMaterial({
      transparent: true,
      uniforms: waterUniforms,
      vertexShader: `uniform float uTime; varying vec2 vUv; void main(){
        vUv = uv; vec3 p = position;
        p.z += sin(p.x * 0.18 + uTime * 1.4) * 0.16 + cos(p.y * 0.14 + uTime) * 0.1;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }`,
      fragmentShader: `uniform float uTime; varying vec2 vUv; void main(){
        float w = sin(vUv.x * 36.0 + uTime) * sin(vUv.y * 22.0 - uTime * 0.8);
        vec3 deep = vec3(0.04, 0.28, 0.38);
        vec3 foam = vec3(0.55, 0.78, 0.74);
        vec3 col = mix(deep, foam, clamp(w * 0.12 + vUv.y * 0.15, 0.0, 0.45));
        gl_FragColor = vec4(col, 0.92);
      }`,
    }),
  );
  water.rotation.x = -Math.PI / 2;
  water.position.set(0, -0.35, ORIGIN + MAP + 30);
  scene.add(water);

  const pierX = roadX(4);
  const pierMat = new THREE.MeshLambertMaterial({ color: 0x8d6246 });
  const deck = new THREE.Mesh(new THREE.BoxGeometry(5.1, 0.28, 22), pierMat);
  deck.position.set(pierX, 0.1, ORIGIN + MAP + 7);
  scene.add(deck);
  for (let i = 0; i < 5; i++) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.4, 0.28), pierMat);
    post.position.set(pierX + (i % 2 === 0 ? -2.2 : 2.2), 0.2, ORIGIN + MAP - 1 + i * 4.2);
    scene.add(post);
  }

  const park = city.spots.park;
  const stone = new THREE.MeshLambertMaterial({ color: 0xc8c0b2 });
  const basin = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.2, 0.5, 12), stone);
  basin.position.set(park.x, 0.25, park.z);
  const basinWater = new THREE.Mesh(
    new THREE.CylinderGeometry(1.45, 1.45, 0.3, 12),
    new THREE.MeshLambertMaterial({ color: 0x3aa0b0, emissive: 0x083038 }),
  );
  basinWater.position.set(park.x, 0.45, park.z);
  scene.add(basin, basinWater);

  function addInstances(
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    count: number,
    place: (dummy: THREE.Object3D, i: number) => void,
  ) {
    const mesh = new THREE.InstancedMesh(geo, mat, Math.max(1, count));
    mesh.frustumCulled = false;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      place(dummy, i);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    if (count === 0) mesh.count = 0;
    scene.add(mesh);
    return mesh;
  }

  const box = new THREE.BoxGeometry(1, 1, 1);
  const buildingMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
  const buildingsMesh = addInstances(box, buildingMat, city.buildings.length, (dummy, i) => {
    const b = city.buildings[i] as Building;
    dummy.position.set((b.minX + b.maxX) / 2, b.h / 2, (b.minZ + b.maxZ) / 2);
    dummy.scale.set(b.maxX - b.minX, b.h, b.maxZ - b.minZ);
    dummy.rotation.set(0, 0, 0);
  });
  city.buildings.forEach((b, i) => buildingsMesh.setColorAt(i, new THREE.Color(b.color)));
  if (buildingsMesh.instanceColor) buildingsMesh.instanceColor.needsUpdate = true;

  const roofMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
  const roofs = addInstances(box, roofMat, city.buildings.length, (dummy, i) => {
    const b = city.buildings[i] as Building;
    const w = b.maxX - b.minX;
    const d = b.maxZ - b.minZ;
    const tall = b.h > 20;
    const rw = tall ? w * 0.46 : w + 0.35;
    const rd = tall ? d * 0.46 : d + 0.35;
    const rh = tall ? 1.4 : 0.42;
    dummy.position.set((b.minX + b.maxX) / 2, b.h + rh / 2, (b.minZ + b.maxZ) / 2);
    dummy.scale.set(rw, rh, rd);
    dummy.rotation.set(0, 0, 0);
  });
  city.buildings.forEach((b, i) => roofs.setColorAt(i, new THREE.Color(b.roof)));
  if (roofs.instanceColor) roofs.instanceColor.needsUpdate = true;

  const glassMat = new THREE.MeshLambertMaterial({
    color: 0xffffff,
    emissive: 0x2a1c10,
    emissiveIntensity: 0.35,
  });
  const glass = addInstances(box, glassMat, city.buildings.length, (dummy, i) => {
    const b = city.buildings[i] as Building;
    const w = b.maxX - b.minX;
    const d = b.maxZ - b.minZ;
    const faceX = (i + Math.floor(b.minZ)) % 2 === 0;
    dummy.position.set((b.minX + b.maxX) / 2, b.h * 0.58, (b.minZ + b.maxZ) / 2);
    dummy.rotation.set(0, 0, 0);
    if (faceX) {
      dummy.position.x = b.minX - 0.05;
      dummy.scale.set(0.08, b.h * 0.62, d * 0.62);
    } else {
      dummy.position.z = b.minZ - 0.05;
      dummy.scale.set(w * 0.62, b.h * 0.62, 0.08);
    }
  });
  city.buildings.forEach((b, i) => {
    const lit = (i * 17) % 5 === 0;
    glass.setColorAt(i, new THREE.Color(lit ? 0xf0d090 : 0x163044));
  });
  if (glass.instanceColor) glass.instanceColor.needsUpdate = true;

  for (const b of city.buildings) {
    if (b.landmark === "hospital") {
      const cx = (b.minX + b.maxX) / 2;
      const cz = (b.minZ + b.maxZ) / 2;
      const y = b.h + 1.5;
      const mat = new THREE.MeshLambertMaterial({ color: 0xd64545, emissive: 0x4a1010 });
      const a = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.35, 0.5), mat);
      const c = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.35, 2.4), mat);
      a.position.set(cx, y, cz);
      c.position.set(cx, y, cz);
      scene.add(a, c);
    }
    if (b.landmark === "safehouse") {
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 2.2, 0.16),
        new THREE.MeshLambertMaterial({ color: 0xf0b429, emissive: 0x3a2a08 }),
      );
      door.position.set((b.minX + b.maxX) / 2, 1.15, b.minZ - 0.12);
      scene.add(door);
    }
  }

  const armeriaSign = makeSign("ARMAS", "#1a120c", "#f0b429");
  armeriaSign.position.set(city.spots.armeria.x, 4.2, city.spots.armeria.z - 1.2);
  const clinicSign = makeSign("CLÍNICA", "#f4f1ea", "#9d2c2c");
  clinicSign.position.set(city.spots.hospital.x, 4.4, city.spots.hospital.z - 1.2);
  const refugioSign = makeSign("REFUGIO", "#1a120c", "#f6f1e7");
  refugioSign.position.set(city.spots.safehouse.x, 3.6, city.spots.safehouse.z - 1.2);
  scene.add(armeriaSign, clinicSign, refugioSign);

  const trees = city.props.filter((p) => p.kind === "tree");
  const palms = city.props.filter((p) => p.kind === "palm");
  const lamps = city.props.filter((p) => p.kind === "lamp");
  const umbrellas = city.props.filter((p) => p.kind === "umbrella");

  const trunkGeo = new THREE.CylinderGeometry(0.16, 0.24, 1.5, 5);
  trunkGeo.translate(0, 0.75, 0);
  const crownGeo = new THREE.SphereGeometry(1.15, 7, 6);
  crownGeo.translate(0, 2.15, 0);
  addInstances(trunkGeo, new THREE.MeshLambertMaterial({ color: 0x6b4a32 }), trees.length, (dummy, i) => {
    const p = trees[i];
    if (!p) return;
    dummy.position.set(p.x, 0, p.z);
    dummy.scale.set(1, 1.1, 1);
    dummy.rotation.set(0, p.rot, 0);
  });
  const crowns = addInstances(
    crownGeo,
    new THREE.MeshLambertMaterial({ color: 0xffffff }),
    trees.length,
    (dummy, i) => {
      const p = trees[i];
      if (!p) return;
      dummy.position.set(p.x, 0, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.rotation.set(0, 0, 0);
    },
  );
  trees.forEach((p, i) => crowns.setColorAt(i, new THREE.Color(p.color)));
  if (crowns.instanceColor) crowns.instanceColor.needsUpdate = true;

  const palmTrunk = new THREE.CylinderGeometry(0.12, 0.18, 3.1, 5);
  palmTrunk.translate(0, 1.55, 0);
  addInstances(palmTrunk, new THREE.MeshLambertMaterial({ color: 0x8a6244 }), palms.length, (dummy, i) => {
    const p = palms[i];
    if (!p) return;
    dummy.position.set(p.x, 0, p.z);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
  });
  const frond = new THREE.ConeGeometry(0.42, 1.5, 4);
  frond.translate(0, 0.4, 0);
  frond.rotateZ(1.15);
  frond.translate(0, 3.15, 0);
  const frondCount = palms.length * 5;
  addInstances(frond, new THREE.MeshLambertMaterial({ color: 0x2f8f4e }), frondCount, (dummy, i) => {
    const p = palms[Math.floor(i / 5)];
    if (!p) return;
    dummy.position.set(p.x, 0, p.z);
    dummy.rotation.set(0, (i % 5) * ((Math.PI * 2) / 5) + p.rot, 0);
    dummy.scale.set(1, 1, 1);
  });

  const pole = new THREE.CylinderGeometry(0.06, 0.08, 4.2, 5);
  pole.translate(0, 2.1, 0);
  addInstances(pole, new THREE.MeshLambertMaterial({ color: 0x2a2e33 }), lamps.length, (dummy, i) => {
    const p = lamps[i];
    if (!p) return;
    dummy.position.set(p.x, 0, p.z);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
  });
  const bulbGeo = new THREE.SphereGeometry(0.16, 6, 5);
  bulbGeo.translate(0, 4.25, 0);
  addInstances(
    bulbGeo,
    new THREE.MeshLambertMaterial({ color: 0xf0d090, emissive: 0xf0b429, emissiveIntensity: 0.8 }),
    lamps.length,
    (dummy, i) => {
      const p = lamps[i];
      if (!p) return;
      dummy.position.set(p.x, 0, p.z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
    },
  );

  const umbPole = new THREE.CylinderGeometry(0.05, 0.05, 1.5, 5);
  umbPole.translate(0, 0.75, 0);
  addInstances(umbPole, new THREE.MeshLambertMaterial({ color: 0xf6f1e7 }), umbrellas.length, (dummy, i) => {
    const p = umbrellas[i];
    if (!p) return;
    dummy.position.set(p.x, 0, p.z);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
  });
  const umbTop = new THREE.ConeGeometry(1.1, 0.45, 8);
  umbTop.translate(0, 1.7, 0);
  const umbMesh = addInstances(
    umbTop,
    new THREE.MeshLambertMaterial({ color: 0xffffff }),
    umbrellas.length,
    (dummy, i) => {
      const p = umbrellas[i];
      if (!p) return;
      dummy.position.set(p.x, 0, p.z);
      dummy.rotation.set(0, p.rot, 0);
      dummy.scale.set(1, 1, 1);
    },
  );
  umbrellas.forEach((p, i) => umbMesh.setColorAt(i, new THREE.Color(p.color)));
  if (umbMesh.instanceColor) umbMesh.instanceColor.needsUpdate = true;

  const carGeo: Record<Kind, THREE.BufferGeometry> = {
    sedan: carGeometry("sedan"),
    sports: carGeometry("sports"),
    van: carGeometry("van"),
    pickup: carGeometry("pickup"),
    taxi: carGeometry("taxi"),
    cop: carGeometry("cop"),
  };
  const carMat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const carMesh: Record<Kind, THREE.InstancedMesh> = {
    sedan: new THREE.InstancedMesh(carGeo.sedan, carMat.clone(), CAP.sedan),
    sports: new THREE.InstancedMesh(carGeo.sports, carMat.clone(), CAP.sports),
    van: new THREE.InstancedMesh(carGeo.van, carMat.clone(), CAP.van),
    pickup: new THREE.InstancedMesh(carGeo.pickup, carMat.clone(), CAP.pickup),
    taxi: new THREE.InstancedMesh(carGeo.taxi, carMat.clone(), CAP.taxi),
    cop: new THREE.InstancedMesh(carGeo.cop, carMat.clone(), CAP.cop),
  };
  for (const k of KINDS) {
    carMesh[k].frustumCulled = false;
    carMesh[k].count = 0;
    scene.add(carMesh[k]);
  }

  const pedMesh = new THREE.InstancedMesh(
    pedGeometry(),
    new THREE.MeshLambertMaterial({ vertexColors: true }),
    12,
  );
  pedMesh.frustumCulled = false;
  scene.add(pedMesh);

  const shirt = new THREE.MeshLambertMaterial({ color: 0x1f8a84 });
  const pants = new THREE.MeshLambertMaterial({ color: 0x1c2430 });
  const skin = new THREE.MeshLambertMaterial({ color: 0xe0b090 });
  const hair = new THREE.MeshLambertMaterial({ color: 0x1a120e });
  const packMat = new THREE.MeshLambertMaterial({ color: 0xc4522a });
  const player = new THREE.Group();
  const legGeo = new THREE.BoxGeometry(0.13, 0.44, 0.14);
  const legL = new THREE.Group();
  const legR = new THREE.Group();
  legL.position.set(-0.1, 0.9, 0);
  legR.position.set(0.1, 0.9, 0);
  const legLm = new THREE.Mesh(legGeo, pants);
  const legRm = new THREE.Mesh(legGeo, pants);
  legLm.position.y = -0.22;
  legRm.position.y = -0.22;
  legL.add(legLm);
  legR.add(legRm);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.48, 0.22), shirt);
  torso.position.y = 1.18;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), skin);
  head.position.y = 1.56;
  const hairM = new THREE.Mesh(new THREE.SphereGeometry(0.155, 10, 8), hair);
  hairM.scale.set(1.02, 0.62, 1.05);
  hairM.position.set(0, 1.66, 0.01);
  const brim = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.04, 0.18), hair);
  brim.position.set(0, 1.6, -0.12);
  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.32, 0.12), packMat);
  backpack.position.set(0, 1.2, 0.16);
  const blob = new THREE.Mesh(
    new THREE.CircleGeometry(0.7, 12),
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false }),
  );
  blob.rotation.x = -Math.PI / 2;
  blob.position.y = 0.03;
  player.add(legL, legR, torso, head, hairM, brim, backpack, blob);
  scene.add(player);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(1.15, 1.7, 28),
    new THREE.MeshBasicMaterial({ color: 0xf0b429, side: THREE.DoubleSide, transparent: true, opacity: 0.95 }),
  );
  ring.rotation.x = -Math.PI / 2;
  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.12, 16, 6),
    new THREE.MeshBasicMaterial({ color: 0xf0b429, transparent: true, opacity: 0.28 }),
  );
  beam.position.y = 8;
  const marker = new THREE.Group();
  marker.add(ring, beam);
  scene.add(marker);

  const tracerGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(),
    new THREE.Vector3(0, 0, -1),
  ]);
  const tracer = new THREE.Line(tracerGeo, new THREE.LineBasicMaterial({ color: 0xf6e27a }));
  tracer.frustumCulled = false;
  tracer.visible = false;
  scene.add(tracer);

  type Drop = { kind: "cash" | "med"; x: number; z: number; alive: boolean; wait: number; mesh: THREE.Object3D };
  const drops: Drop[] = [];
  for (const spot of city.spots.cash) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.28, 0.4),
      new THREE.MeshLambertMaterial({ color: 0xf0b429, emissive: 0x5a3e08 }),
    );
    mesh.position.set(spot.x, 0.6, spot.z);
    scene.add(mesh);
    drops.push({ kind: "cash", x: spot.x, z: spot.z, alive: true, wait: 0, mesh });
  }
  for (const spot of city.spots.meds) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.42, 0.42),
      new THREE.MeshLambertMaterial({ color: 0xd64545, emissive: 0x3a1010 }),
    );
    mesh.position.set(spot.x, 0.55, spot.z);
    scene.add(mesh);
    drops.push({ kind: "med", x: spot.x, z: spot.z, alive: true, wait: 0, mesh });
  }

  const cars: Car[] = [];
  const peds: Ped[] = [];
  const buckets: Record<Kind, Car[]> = {
    sedan: [],
    sports: [],
    van: [],
    pickup: [],
    taxi: [],
    cop: [],
  };
  const dummy = new THREE.Object3D();
  const desired = new THREE.Vector3();
  const look = new THREE.Vector3();

  function addCar(partial: Omit<Car, "hp" | "speed" | "color"> & { color: number; speed?: number }) {
    const count = cars.filter((c) => c.kind === partial.kind).length;
    if (count >= CAP[partial.kind]) return null;
    const car: Car = {
      ...partial,
      color: new THREE.Color(partial.color),
      speed: partial.speed ?? 0,
      hp: partial.kind === "cop" ? 80 : 50,
    };
    cars.push(car);
    return car;
  }

  const parked: { id: string; kind: Kind; x: number; z: number; yaw: number; color: number }[] = [
    { id: "van", kind: "van", x: roadX(3) + 3.3, z: roadZ(3) + 15, yaw: Math.PI, color: 0x2f7d4a },
    { id: "lince", kind: "sports", x: roadX(3) - 3.3, z: roadZ(3) - 14, yaw: 0, color: 0xc7372f },
    { id: "nube", kind: "sedan", x: roadX(4) + 3.3, z: roadZ(2) + 12, yaw: Math.PI, color: 0xd9d3c7 },
    { id: "cerro", kind: "pickup", x: roadX(5) - 3.3, z: roadZ(4) + 8, yaw: 0, color: 0x3d5a80 },
    { id: "abeja", kind: "taxi", x: roadX(2) - 3.3, z: roadZ(5) + 10, yaw: Math.PI, color: 0xf0c430 },
    { id: "lince2", kind: "sports", x: roadX(6) + 3.3, z: roadZ(6) - 8, yaw: 0, color: 0xe0a020 },
  ];
  for (const p of parked) {
    addCar({ ...p, ai: "parked", axis: "z", dir: 1, lane: p.x, speed: 0 });
  }

  let laneCursor = 0;
  const laneDefs: { axis: "x" | "z"; lane: number; dir: 1 | -1 }[] = [];
  for (let i = 0; i <= BLOCKS; i += 2) laneDefs.push({ axis: "z", lane: roadX(i), dir: i % 4 === 0 ? 1 : -1 });
  for (let k = 1; k <= BLOCKS; k += 2) laneDefs.push({ axis: "x", lane: roadZ(k), dir: k % 4 === 0 ? 1 : -1 });
  const trafficPlan: { kind: Kind; color: number }[] = [
    { kind: "sedan", color: 0xb7c0c8 },
    { kind: "sedan", color: 0x8e5a4a },
    { kind: "sedan", color: 0xded4c4 },
    { kind: "pickup", color: 0x4d6a4a },
    { kind: "pickup", color: 0x6a5a48 },
    { kind: "taxi", color: 0xf0c430 },
    { kind: "sedan", color: 0x35556e },
    { kind: "taxi", color: 0xe6b325 },
  ];
  for (const plan of trafficPlan) {
    const lane = laneDefs[laneCursor % laneDefs.length];
    laneCursor++;
    if (!lane) continue;
    const t = ORIGIN + 30 + (laneCursor * 37) % (MAP - 70);
    const pose =
      lane.axis === "z"
        ? { x: lane.lane, z: t, yaw: lane.dir > 0 ? Math.PI : 0 }
        : { x: t, z: lane.lane, yaw: lane.dir > 0 ? -Math.PI / 2 : Math.PI / 2 };
    let crowded = false;
    for (const c of cars) if (Math.hypot(c.x - pose.x, c.z - pose.z) < 8) crowded = true;
    if (crowded) continue;
    addCar({
      id: "t" + laneCursor,
      kind: plan.kind,
      ...pose,
      ai: "traffic",
      axis: lane.axis,
      dir: lane.dir,
      lane: lane.lane,
      color: plan.color,
      speed: 7 + (laneCursor % 3),
    });
  }

  const pedColors = [0xe07a5f, 0x3d5a80, 0xf2cc8f, 0x81b29a, 0xf4f1de, 0xc4522a, 0x6f7c8a, 0xe9c46a];
  const pedBlocks = [
    [2, 4],
    [3, 5],
    [4, 2],
    [5, 4],
    [1, 4],
    [6, 5],
    [4, 5],
    [2, 5],
    [5, 2],
    [6, 2],
  ];
  for (let n = 0; n < pedBlocks.length; n++) {
    const pair = pedBlocks[n];
    if (!pair) continue;
    const i = pair[0] ?? 0;
    const k = pair[1] ?? 0;
    const lotX0 = ORIGIN + ROAD + i * STRIDE;
    const lotZ0 = ORIGIN + ROAD + k * STRIDE;
    const s = 1.15;
    const points = [
      { x: lotX0 + s, z: lotZ0 + s },
      { x: lotX0 + BLOCK - s, z: lotZ0 + s },
      { x: lotX0 + BLOCK - s, z: lotZ0 + BLOCK - s },
      { x: lotX0 + s, z: lotZ0 + BLOCK - s },
    ];
    const start = points[n % 4] ?? points[0];
    if (!start) continue;
    peds.push({
      x: start.x,
      z: start.z,
      yaw: 0,
      state: "walk",
      downT: 0,
      reported: false,
      points,
      pi: (n + 1) % 4,
      speed: 1.15 + (n % 3) * 0.25,
      color: new THREE.Color(pedColors[n % pedColors.length] ?? 0xe07a5f),
    });
  }

  let phase: Hud["phase"] = "menu";
  let x = city.spots.spawn.x;
  let z = city.spots.spawn.z;
  let yaw = 0;
  let speed = 0;
  let health = 100;
  let money = 250;
  let stars = 0;
  let ammo = 0;
  let pistol = false;
  let inCar = false;
  let playerCar: Car | null = null;
  let run: Run | null = null;
  const done = new Set<string>();
  let toast = "";
  let toastT = 0;
  let deadTitle = "";
  let deadText = "";
  let deadT = 0;
  let attackCd = 0;
  let invuln = 0;
  let hurtGap = 10;
  let crimeLock = 0;
  let unseen = 0;
  let bustT = 0;
  let trauma = 0;
  let tracerT = 0;
  let clockMin = 17 * 60 + 40;
  let travel = 0;
  let menuAng = 0.4;
  let hudAcc = 0;
  let camDist = 16;
  let camHeight = 8;
  let shopHint = false;
  let alive = true;
  let raf = 0;

  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const s = JSON.parse(raw) as { v?: number; money?: number; ammo?: number; pistol?: boolean; done?: string[] };
      if (s.v === 1) {
        if (typeof s.money === "number") money = s.money;
        if (typeof s.ammo === "number") ammo = s.ammo;
        if (typeof s.pistol === "boolean") pistol = s.pistol;
        for (const id of s.done ?? []) done.add(id);
      }
    }
  } catch {
    /* ignore broken saves */
  }

  function save() {
    try {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({ v: 1, money, ammo, pistol, done: [...done] }),
      );
    } catch {
      /* private mode */
    }
  }

  function toastMsg(text: string) {
    toast = text;
    toastT = 2.6;
  }

  function objective(): { x: number; z: number; r: number; text: string } | null {
    if (!run) return null;
    if (run.id === "furgoneta") {
      const van = cars.find((c) => c.id === "van");
      const vx = van?.x ?? city.spots.spawn.x;
      const vz = van?.z ?? city.spots.spawn.z;
      if (run.step === 0 || !(inCar && playerCar?.id === "van")) {
        return { x: vx, z: vz, r: 3, text: run.step === 0 ? "Sube a la furgoneta verde" : "Vuelve a la furgoneta" };
      }
      return { x: city.spots.dock.x, z: city.spots.dock.z, r: 7, text: "Lleva el Toro al muelle" };
    }
    if (run.id === "cobro") {
      if (run.step === 0) return { x: city.spots.contact.x, z: city.spots.contact.z, r: 4, text: "Recoge el paquete en la playa" };
      return { x: city.spots.safehouse.x, z: city.spots.safehouse.z, r: 5, text: "Vuelve al refugio de Barrio Alto" };
    }
    if (run.id === "fuga") {
      return { x: city.spots.hideout.x, z: city.spots.hideout.z, r: 6, text: "Pierde el ritmo y entra a Barrio Alto" };
    }
    const cp = city.spots.race[run.step];
    if (!cp) return null;
    return {
      x: cp.x,
      z: cp.z,
      r: 7,
      text: `Punto ${run.step + 1}/5 · ${Math.ceil(run.left)}s`,
    };
  }

  function clearLooseCops() {
    for (let i = cars.length - 1; i >= 0; i--) {
      const c = cars[i];
      if (c && c.kind === "cop" && c !== playerCar) cars.splice(i, 1);
    }
  }

  function spawnCop() {
    if (cars.filter((c) => c.kind === "cop").length >= CAP.cop) return;
    for (let attempt = 0; attempt < 14; attempt++) {
      const i = 1 + Math.floor(Math.random() * (BLOCKS - 1));
      const k = 1 + Math.floor(Math.random() * (BLOCKS - 1));
      const sx = roadX(i);
      const sz = roadZ(k);
      if (Math.hypot(sx - x, sz - z) < 34) continue;
      addCar({
        id: "cop" + attempt + stars,
        kind: "cop",
        x: sx,
        z: sz,
        yaw: Math.atan2(-(x - sx), -(z - sz)),
        ai: "cop",
        axis: "z",
        dir: 1,
        lane: sx,
        color: 0xeef2f4,
        speed: 8,
      });
      return;
    }
  }

  function ensureCops() {
    const need = Math.min(3, stars);
    let have = 0;
    for (const c of cars) if (c.ai === "cop") have++;
    while (have < need) {
      const before = cars.length;
      spawnCop();
      if (cars.length === before) break;
      have++;
    }
  }

  function setWanted(n: number) {
    stars = Math.max(0, Math.min(4, n));
    unseen = 0;
    if (stars <= 0) clearLooseCops();
    else ensureCops();
  }

  function commitCrime(level: number) {
    unseen = 0;
    if (crimeLock > 0) {
      if (stars < level) setWanted(level);
      return;
    }
    crimeLock = 0.9;
    setWanted(Math.min(4, Math.max(stars + level, level)));
  }

  function downPed(p: Ped) {
    if (p.state === "down") return;
    p.state = "down";
    p.downT = 0;
    if (!p.reported) {
      p.reported = true;
      money += 15;
      commitCrime(1);
      audio.hit();
    }
  }

  function fail(text: string) {
    toastMsg(text);
    run = null;
    audio.hit();
  }

  function complete() {
    if (!run) return;
    const meta = MISSIONS.find((m) => m.id === run?.id);
    if (!meta) return;
    const bonus = run.id === "carrera" ? Math.floor(Math.max(0, run.left) * 12) : 0;
    money += meta.reward + bonus;
    done.add(meta.id);
    toastMsg(`${meta.title}  +$${meta.reward + bonus}`);
    audio.cash();
    if (run.id === "fuga") setWanted(0);
    run = null;
    save();
  }

  function begin(id: MissionId) {
    run = { id, step: 0, left: id === "carrera" ? 75 : 0 };
    const meta = MISSIONS.find((m) => m.id === id);
    toastMsg(meta?.title ?? "Encargo");
    audio.blip();
    if (id === "fuga") setWanted(Math.max(stars, 2));
  }

  function nearestCar(radius: number) {
    let best: Car | null = null;
    let bestD = radius;
    for (const c of cars) {
      if (c === playerCar) continue;
      const d = Math.hypot(c.x - x, c.z - z);
      if (d < bestD) {
        bestD = d;
        best = c;
      }
    }
    return best;
  }

  function enterCar(c: Car) {
    if (playerCar && playerCar !== c) {
      playerCar.ai = "parked";
      playerCar.speed = 0;
    }
    if (c.ai === "traffic") commitCrime(1);
    if (c.kind === "cop") commitCrime(2);
    c.ai = "player";
    playerCar = c;
    inCar = true;
    x = c.x;
    z = c.z;
    yaw = c.yaw;
    speed = c.speed;
    audio.blip();
  }

  function exitCar() {
    if (!playerCar) return;
    const rx = Math.cos(playerCar.yaw);
    const rz = -Math.sin(playerCar.yaw);
    let ex = playerCar.x + rx * 2.35;
    let ez = playerCar.z + rz * 2.35;
    let res = resolveCircle(ex, ez, 0.45, solids);
    if (Math.hypot(res.x - playerCar.x, res.z - playerCar.z) < 1.2) {
      ex = playerCar.x - rx * 2.35;
      ez = playerCar.z - rz * 2.35;
      res = resolveCircle(ex, ez, 0.45, solids);
    }
    x = res.x;
    z = res.z;
    yaw = playerCar.yaw;
    speed = 0;
    playerCar.speed = 0;
    playerCar.ai = "parked";
    playerCar = null;
    inCar = false;
  }

  function useShop() {
    if (!pistol) {
      if (money < 350) {
        toastMsg("La pistola sale $350");
        return;
      }
      money -= 350;
      pistol = true;
      ammo += 24;
      toastMsg("Pistola lista. 24 balas.");
    } else {
      if (money < 40) {
        toastMsg("Cargador: $40");
        return;
      }
      money -= 40;
      ammo += 12;
      toastMsg("+12 balas");
    }
    audio.cash();
    save();
  }

  function knockdown() {
    deadTitle = bustT > 2 ? "TE AGARRARON" : "TE CAÍSTE";
    deadText = bustT > 2 ? "La patrulla cierra el caso. Clínica, y a empezar de nuevo." : "Despiertas en la clínica. El barrio sigue ahí.";
    const fine = bustT > 2 ? 300 : 150;
    money = Math.max(0, money - fine);
    phase = "dead";
    deadT = 0;
    setWanted(0);
    save();
    pushHud(true);
  }

  function hurt(amount: number) {
    if (invuln > 0 || phase !== "play") return;
    health = Math.max(0, health - amount);
    invuln = 0.55;
    hurtGap = 0;
    trauma = Math.min(1, trauma + 0.45);
    audio.hit();
    if (health <= 0) knockdown();
  }

  function respawn() {
    if (inCar) exitCar();
    x = city.spots.hospital.x;
    z = city.spots.hospital.z;
    yaw = Math.PI;
    speed = 0;
    health = 100;
    bustT = 0;
    phase = "play";
    player.visible = true;
    pushHud(true);
  }

  function fire() {
    if (attackCd > 0 || phase !== "play") return;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    if (pistol) {
      if (ammo <= 0) {
        toastMsg("Sin balas. La armería está en Zona Férrea.");
        attackCd = 0.45;
        return;
      }
      ammo -= 1;
      attackCd = 0.28;
      audio.shot();
      let best = 36;
      let hitP: Ped | null = null;
      let hitC: Car | null = null;
      for (const p of peds) {
        if (p.state === "down") continue;
        const dx = p.x - x;
        const dz = p.z - z;
        const along = dx * fx + dz * fz;
        if (along < 0 || along > best) continue;
        const lat2 = dx * dx + dz * dz - along * along;
        if (lat2 < 0.7) {
          best = along;
          hitP = p;
          hitC = null;
        }
      }
      for (const c of cars) {
        if (c === playerCar) continue;
        const dx = c.x - x;
        const dz = c.z - z;
        const along = dx * fx + dz * fz;
        if (along < 0.5 || along > best) continue;
        const lat2 = dx * dx + dz * dz - along * along;
        if (lat2 < 1.8) {
          best = along;
          hitC = c;
          hitP = null;
        }
      }
      if (hitP) downPed(hitP);
      if (hitC) {
        hitC.hp -= 28;
        commitCrime(1);
        trauma = Math.min(1, trauma + 0.15);
        if (hitC.hp <= 0 && hitC !== playerCar) {
          hitC.ai = "parked";
          hitC.speed = 0;
        }
      }
      const attr = tracer.geometry.getAttribute("position") as THREE.BufferAttribute;
      attr.setXYZ(0, x, 1.25, z);
      attr.setXYZ(1, x + fx * best, 1.15, z + fz * best);
      attr.needsUpdate = true;
      tracer.visible = true;
      tracerT = 0.07;
      return;
    }
    attackCd = 0.42;
    audio.swing();
    travel += 0.2;
    for (const p of peds) {
      if (p.state === "down") continue;
      const dx = p.x - x;
      const dz = p.z - z;
      if (Math.hypot(dx, dz) < 1.75 && dx * fx + dz * fz > 0.15) downPed(p);
    }
  }

  function updateTraffic(dt: number) {
    const minR = ORIGIN + 10;
    const maxR = ORIGIN + MAP - 10;
    for (const car of cars) {
      if (car.ai === "parked" || car.ai === "player") continue;
      if (car.ai === "cop") {
        const dx = x - car.x;
        const dz = z - car.z;
        const desiredYaw = Math.atan2(-dx, -dz);
        const diff = Math.atan2(Math.sin(desiredYaw - car.yaw), Math.cos(desiredYaw - car.yaw));
        const steer = Math.max(-1, Math.min(1, diff * 1.35));
        const spf = Math.max(0.4, Math.min(1, Math.abs(car.speed) / 7));
        car.yaw += steer * SPECS.cop.turn * spf * dt;
        const target = SPECS.cop.vmax * (Math.hypot(dx, dz) < 8 ? 0.55 : 0.95);
        car.speed += (target - car.speed) * Math.min(1, dt * 1.6);
      } else {
        if (car.axis === "z") {
          car.x += (car.lane - car.x) * Math.min(1, dt * 3);
          car.yaw = car.dir > 0 ? Math.PI : 0;
          const next = car.z + car.dir * car.speed * dt;
          if (next < minR || next > maxR) car.dir = (car.dir * -1) as 1 | -1;
        } else {
          car.z += (car.lane - car.z) * Math.min(1, dt * 3);
          car.yaw = car.dir > 0 ? -Math.PI / 2 : Math.PI / 2;
        }
        const capped = 6.5 + (car.hp % 5) * 0.4;
        if (car.speed > capped) car.speed = capped;
        if (car.speed < capped) car.speed += dt * 4;
      }
      const fx = -Math.sin(car.yaw);
      const fz = -Math.cos(car.yaw);
      const res = resolveCircle(car.x + fx * car.speed * dt, car.z + fz * car.speed * dt, 1.2, solids);
      if (res.hit && car.ai === "traffic") car.dir = (car.dir * -1) as 1 | -1;
      car.x = res.x;
      car.z = res.z;
    }

    for (let i = 0; i < cars.length; i++) {
      for (let j = i + 1; j < cars.length; j++) {
        const a = cars[i];
        const b = cars[j];
        if (!a || !b) continue;
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const d = Math.hypot(dx, dz);
        const min = 2.55;
        if (d >= min || d < 1e-4) continue;
        const push = (min - d) * 0.5;
        const nx = dx / d;
        const nz = dz / d;
        a.x -= nx * push;
        a.z -= nz * push;
        b.x += nx * push;
        b.z += nz * push;
        if (a.ai === "player" || b.ai === "player") {
          const p = a.ai === "player" ? a : b;
          if (Math.abs(p.speed) > 8) {
            p.speed *= 0.55;
            trauma = Math.min(1, trauma + 0.25);
            commitCrime(1);
            hurt(6);
          } else p.speed *= 0.8;
        }
      }
    }

    for (const car of cars) {
      const res = resolveCircle(car.x, car.z, 1.15, solids);
      car.x = res.x;
      car.z = res.z;
    }
    if (inCar && playerCar) {
      x = playerCar.x;
      z = playerCar.z;
      yaw = playerCar.yaw;
      speed = playerCar.speed;
    }
  }

  function updatePeds(dt: number) {
    for (const p of peds) {
      if (p.state === "down") {
        p.downT += dt;
        if (p.downT > 9) {
          const home = p.points[0];
          if (home) {
            p.x = home.x;
            p.z = home.z;
          }
          p.state = "walk";
          p.reported = false;
          p.downT = 0;
        }
        continue;
      }
      const target = p.points[p.pi];
      if (!target) continue;
      const dx = target.x - p.x;
      const dz = target.z - p.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.4) p.pi = (p.pi + 1) % p.points.length;
      else {
        p.x += (dx / d) * p.speed * dt;
        p.z += (dz / d) * p.speed * dt;
        p.yaw = Math.atan2(-dx, -dz);
      }
      const px = p.x - x;
      const pz = p.z - z;
      const pd = Math.hypot(px, pz);
      if (pd < 0.95 && pd > 0.001) {
        p.x += (px / pd) * (0.95 - pd);
        p.z += (pz / pd) * (0.95 - pd);
        const impact = inCar ? Math.abs(speed) : 0;
        if (impact > 7) {
          downPed(p);
          speed *= 0.92;
        }
      }
    }
  }

  function updateDrops(dt: number) {
    for (const drop of drops) {
      if (!drop.alive) {
        drop.wait -= dt;
        drop.mesh.visible = false;
        if (drop.wait <= 0) {
          drop.alive = true;
          drop.mesh.visible = true;
        }
        continue;
      }
      drop.mesh.visible = true;
      drop.mesh.rotation.y += dt * 1.4;
      drop.mesh.position.y = 0.55 + Math.sin(performance.now() / 280 + drop.x) * 0.08;
      if (Math.hypot(drop.x - x, drop.z - z) < 1.5) {
        drop.alive = false;
        drop.wait = drop.kind === "cash" ? 22 : 30;
        if (drop.kind === "cash") {
          money += 80;
          toastMsg("+$80");
        } else {
          health = Math.min(100, health + 35);
          toastMsg("Botiquín");
        }
        audio.cash();
        save();
      }
    }
  }

  function drivePlayer(dt: number, useEdges: boolean) {
    const a = input.actions;
    if (useEdges && a.interactEdge) {
      if (inCar) exitCar();
      else if (Math.hypot(x - city.spots.armeria.x, z - city.spots.armeria.z) < 3.4) useShop();
      else {
        const near = nearestCar(3);
        if (near) enterCar(near);
      }
    }
    if (a.attack) fire();

    if (!inCar || !playerCar) {
      const steer = a.steer;
      const thr = a.throttle;
      const sprint = a.handbrake;
      const reverse = speed >= 0 ? 1 : -1;
      yaw += steer * 3.15 * reverse * dt;
      const max = sprint ? 9.2 : 6.05;
      const target = thr * max;
      speed += (target - speed) * Math.min(1, dt * 7);
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      const nx = x + fx * speed * dt;
      const nz = z + fz * speed * dt;
      const res = resolveCircle(nx, nz, 0.42, solids);
      if (res.hit && Math.hypot(res.x - x, res.z - z) < Math.abs(speed) * dt * 0.35) speed *= 0.3;
      x = res.x;
      z = res.z;
      if (Math.abs(speed) > 0.4) travel += Math.abs(speed) * dt;
      return;
    }

    const spec = SPECS[playerCar.kind];
    const steer = a.steer;
    const thr = a.throttle;
    if (thr > 0) playerCar.speed += thr * spec.accel * dt;
    else if (thr < 0) {
      if (playerCar.speed > 1.2) playerCar.speed -= 24 * dt;
      else playerCar.speed += thr * spec.accel * 0.45 * dt;
    }
    playerCar.speed -= playerCar.speed * 0.38 * dt;
    if (a.handbrake) playerCar.speed -= Math.sign(playerCar.speed || 0) * 16 * dt;
    const limit = spec.vmax;
    if (playerCar.speed > limit) playerCar.speed = limit;
    if (playerCar.speed < -limit * 0.34) playerCar.speed = -limit * 0.34;
    const spf = Math.max(0.22, Math.min(1, Math.abs(playerCar.speed) / 7));
    const reverse = playerCar.speed >= 0 ? 1 : -1;
    playerCar.yaw += steer * spec.turn * spf * reverse * dt;
    if (a.handbrake) playerCar.yaw += steer * 1.05 * dt;
    const fx = -Math.sin(playerCar.yaw);
    const fz = -Math.cos(playerCar.yaw);
    const intendX = playerCar.x + fx * playerCar.speed * dt;
    const intendZ = playerCar.z + fz * playerCar.speed * dt;
    const res = resolveCircle(intendX, intendZ, 1.25, solids);
    const blocked = Math.hypot(res.x - intendX, res.z - intendZ) > 0.08;
    playerCar.x = res.x;
    playerCar.z = res.z;
    if (blocked && Math.abs(playerCar.speed) > 8) {
      if (Math.abs(playerCar.speed) > 16) hurt(8);
      playerCar.speed *= 0.35;
      trauma = Math.min(1, trauma + 0.35);
    }
    x = playerCar.x;
    z = playerCar.z;
    yaw = playerCar.yaw;
    speed = playerCar.speed;
  }

  function updateMission(dt: number) {
    if (!run || phase !== "play") return;
    if (run.id === "furgoneta") {
      const van = cars.find((c) => c.id === "van");
      if (run.step === 0 && inCar && playerCar?.id === "van") {
        run.step = 1;
        audio.blip();
      }
      if (run.step === 1 && inCar && playerCar?.id === "van") {
        if (Math.hypot(x - city.spots.dock.x, z - city.spots.dock.z) < 7) complete();
      }
      if (van && run.step === 0) {
        /* marker follows van via objective() */
      }
    } else if (run.id === "cobro") {
      const spot = run.step === 0 ? city.spots.contact : city.spots.safehouse;
      const r = run.step === 0 ? 4 : 5;
      if (Math.hypot(x - spot.x, z - spot.z) < r) {
        if (run.step === 0) {
          run.step = 1;
          toastMsg("Paquete contigo");
          audio.blip();
        } else complete();
      }
    } else if (run.id === "fuga") {
      if (Math.hypot(x - city.spots.hideout.x, z - city.spots.hideout.z) < 6) complete();
    } else if (run.id === "carrera") {
      run.left -= dt;
      const cp = city.spots.race[run.step];
      if (cp && Math.hypot(x - cp.x, z - cp.z) < 7) {
        run.step += 1;
        audio.blip();
        if (run.step >= city.spots.race.length) complete();
      }
      if (run && run.left <= 0) fail("Se acabó el tiempo");
    }
  }

  function simulate(dt: number, useEdges: boolean) {
    if (toastT > 0) toastT -= dt;
    if (toastT <= 0) toast = "";
    attackCd = Math.max(0, attackCd - dt);
    invuln = Math.max(0, invuln - dt);
    crimeLock = Math.max(0, crimeLock - dt);
    hurtGap += dt;
    tracerT -= dt;
    if (tracerT <= 0) tracer.visible = false;

    if (useEdges && input.actions.pauseEdge) {
      if (phase === "play") phase = "pause";
      else if (phase === "pause") phase = "play";
    }
    if (useEdges && input.actions.radioEdge && phase === "play") {
      audio.unlock();
      const order = [0, 1, 2];
      const idx = order.indexOf(audio.station);
      audio.setStation(order[(idx + 1) % order.length] ?? 0);
      toastMsg(audio.station === 0 ? "Radio off" : audio.station === 1 ? "Ola FM" : "Norte 88");
    }

    if (phase === "menu") {
      menuAng += dt * 0.12;
      updateTraffic(dt);
      updatePeds(dt);
      return;
    }
    if (phase === "pause") return;
    if (phase === "dead") {
      deadT += dt;
      if (deadT > 2.6) respawn();
      return;
    }

    clockMin += dt / 7;
    drivePlayer(dt, useEdges);
    updateTraffic(dt);
    updatePeds(dt);
    updateDrops(dt);
    updateMission(dt);

    if (stars > 0) {
      let close = false;
      let touching = false;
      for (const c of cars) {
        if (c.ai !== "cop") continue;
        const d = Math.hypot(c.x - x, c.z - z);
        if (d < 46) close = true;
        if (d < 2.3) touching = true;
      }
      if (close) unseen = 0;
      else unseen += dt;
      if (unseen > 8) setWanted(stars - 1);
      if (touching && Math.abs(speed) < 4) bustT += dt;
      else bustT = Math.max(0, bustT - dt * 0.5);
      if (bustT > 2.15 && health > 0) {
        bustT = 2.2;
        health = 0;
        knockdown();
      }
    } else bustT = 0;

    if (hurtGap > 7 && health < 100 && health > 0) health = Math.min(100, health + 6 * dt);

    const shopNear = !inCar && Math.hypot(x - city.spots.armeria.x, z - city.spots.armeria.z) < 3.4;
    if (shopNear && !shopHint) {
      shopHint = true;
      toastMsg(pistol ? "E  ·  balas $40" : "E  ·  pistola $350");
    }
    if (!shopNear) shopHint = false;
  }

  function radioLabel() {
    if (audio.station === 1) return "Ola FM";
    if (audio.station === 2) return "Norte 88";
    return "Radio off";
  }

  function pushHud(force = false) {
    if (!force && hudAcc < 0.12) return;
    hudAcc = 0;
    const obj = objective();
    let arrow = 0;
    let dist = 0;
    let showArrow = false;
    if (obj && phase === "play") {
      const dx = obj.x - x;
      const dz = obj.z - z;
      dist = Math.hypot(dx, dz);
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      const rx = Math.cos(yaw);
      const rz = -Math.sin(yaw);
      arrow = Math.atan2(dx * rx + dz * rz, dx * fx + dz * fz);
      showArrow = dist > 14;
    }
    const meta = run ? MISSIONS.find((m) => m.id === run?.id) : undefined;
    const hud: Hud = {
      ...INITIAL_HUD,
      phase,
      money: Math.floor(money),
      health: Math.max(0, Math.round(health)),
      stars,
      speedKmh: Math.abs(Math.round(speed * 3.6)),
      inCar,
      carName: inCar && playerCar ? SPECS[playerCar.kind].name : "",
      weapon: pistol ? "Pistola" : "Puños",
      ammo,
      pistol,
      missionTitle: meta?.title ?? "",
      missionText: obj?.text ?? (phase === "play" ? "Sin encargo. Pausa y elige uno." : INITIAL_HUD.missionText),
      toast: toastT > 0 ? toast : "",
      district: DISTRICT_NAME[districtAt(x, z)],
      clock: formatClock(clockMin),
      radio: radioLabel(),
      arrow,
      dist: Math.round(dist),
      showArrow,
      deadTitle,
      deadText,
      done: [...done],
      active: run?.id ?? "",
      low: health < 40 && health > 0,
    };
    onHud(hud);
  }

  function formatClock(mins: number) {
    const total = Math.floor(mins);
    const h = Math.floor(total / 60) % 24;
    const m = total % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  }

  function syncMeshes(dt: number) {
    for (const k of KINDS) buckets[k].length = 0;
    for (const c of cars) buckets[c.kind].push(c);
    for (const k of KINDS) {
      const mesh = carMesh[k];
      const list = buckets[k];
      mesh.count = list.length;
      for (let i = 0; i < list.length; i++) {
        const c = list[i];
        if (!c) continue;
        dummy.position.set(c.x, 0, c.z);
        dummy.rotation.set(0, c.yaw, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
        mesh.setColorAt(i, c.color);
      }
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    }

    for (let i = 0; i < peds.length; i++) {
      const p = peds[i];
      if (!p) continue;
      dummy.position.set(p.x, p.state === "down" ? 0.35 : Math.abs(Math.sin(travel + i)) * 0.04, p.z);
      dummy.rotation.set(p.state === "down" ? Math.PI / 2 : 0, p.yaw, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      pedMesh.setMatrixAt(i, dummy.matrix);
      pedMesh.setColorAt(i, p.color);
    }
    pedMesh.count = peds.length;
    pedMesh.instanceMatrix.needsUpdate = true;
    if (pedMesh.instanceColor) pedMesh.instanceColor.needsUpdate = true;

    player.visible = !inCar;
    player.position.set(x, 0, z);
    player.rotation.y = yaw;
    const stepping = !inCar && Math.abs(speed) > 0.8;
    const swing = stepping ? Math.sin(travel * 2.2) * 0.7 : 0;
    legL.rotation.x = swing;
    legR.rotation.x = -swing;

    const obj = objective();
    marker.visible = !!obj && phase === "play";
    if (obj) {
      marker.position.set(obj.x, 0.15, obj.z);
      const pulse = 1 + Math.sin(performance.now() / 180) * 0.08;
      ring.scale.set(pulse, pulse, pulse);
    }

    waterUniforms.uTime.value += dt;
  }

  function drawMap() {
    if (!mapCtx) return;
    const S = mapCanvas.width;
    mapCtx.clearRect(0, 0, S, S);
    mapCtx.save();
    mapCtx.beginPath();
    mapCtx.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2);
    mapCtx.clip();
    mapCtx.fillStyle = "#1a2420";
    mapCtx.fillRect(0, 0, S, S);
    const R = 70;
    const scale = S / 2 / R;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    const rx = Math.cos(yaw);
    const rz = -Math.sin(yaw);
    mapCtx.translate(S / 2, S / 2);
    mapCtx.transform(scale * rx, scale * -fx, scale * rz, scale * -fz, 0, 0);
    mapCtx.translate(-x, -z);
    mapCtx.fillStyle = "#5c564c";
    for (const b of city.buildings) {
      mapCtx.fillRect(b.minX, b.minZ, b.maxX - b.minX, b.maxZ - b.minZ);
    }
    mapCtx.fillStyle = "#8b939c";
    for (let i = 0; i <= BLOCKS; i++) mapCtx.fillRect(ORIGIN + i * STRIDE, ORIGIN, ROAD, MAP);
    for (let k = 0; k <= BLOCKS; k++) mapCtx.fillRect(ORIGIN, ORIGIN + k * STRIDE, MAP, ROAD);
    mapCtx.fillStyle = "#d64545";
    for (const c of cars) {
      if (c.ai !== "cop") continue;
      mapCtx.beginPath();
      mapCtx.arc(c.x, c.z, 1.4, 0, Math.PI * 2);
      mapCtx.fill();
    }
    const obj = objective();
    if (obj) {
      mapCtx.fillStyle = "#f0b429";
      mapCtx.beginPath();
      mapCtx.arc(obj.x, obj.z, 2.1, 0, Math.PI * 2);
      mapCtx.fill();
    }
    mapCtx.restore();
    mapCtx.fillStyle = "#f0b429";
    mapCtx.beginPath();
    mapCtx.moveTo(S / 2, S / 2 - 7);
    mapCtx.lineTo(S / 2 - 5, S / 2 + 6);
    mapCtx.lineTo(S / 2 + 5, S / 2 + 6);
    mapCtx.closePath();
    mapCtx.fill();
  }

  function blockedCam(cx: number, cy: number, cz: number) {
    for (const b of solids) {
      if (cy > b.h + 0.4) continue;
      if (cx > b.minX && cx < b.maxX && cz > b.minZ && cz < b.maxZ) return true;
    }
    return false;
  }

  function render(dt: number) {
    if (phase === "menu") {
      const ang = menuAng;
      camera.position.set(park.x + Math.sin(ang) * 72, 78, park.z + Math.cos(ang) * 58);
      camera.lookAt(park.x, 0, park.z);
    } else {
      const wantDist = inCar ? 9.8 : 6.3;
      const wantH = inCar ? 3.85 : 2.75;
      camDist += (wantDist - camDist) * (1 - Math.exp(-3.2 * dt));
      camHeight += (wantH - camHeight) * (1 - Math.exp(-3.2 * dt));
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      let dist = camDist;
      for (let i = 0; i < 5; i++) {
        const cx = x - fx * dist;
        const cz = z - fz * dist;
        if (!blockedCam(cx, camHeight, cz)) break;
        dist *= 0.72;
      }
      const mag = trauma * trauma;
      trauma = Math.max(0, trauma - dt * 1.6);
      desired.set(
        x - fx * dist + (Math.random() - 0.5) * mag,
        camHeight + (Math.random() - 0.5) * mag * 0.4,
        z - fz * dist + (Math.random() - 0.5) * mag,
      );
      const k = 1 - Math.exp(-5 * dt);
      camera.position.lerp(desired, k);
      look.set(x, inCar ? 1.05 : 1.3, z);
      camera.lookAt(look);
    }
    renderer.render(scene, camera);
    if (phase !== "menu") drawMap();
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  }
  resize();
  const ro = new ResizeObserver(() => resize());
  ro.observe(container);

  let acc = 0;
  let last = performance.now();
  function frame(now: number) {
    if (!alive) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    hudAcc += dt;
    acc += dt;
    input.sample();
    let guard = 0;
    let first = true;
    while (acc >= STEP && guard < 5) {
      simulate(STEP, first);
      first = false;
      acc -= STEP;
      guard++;
    }
    if (guard === 5) acc = 0;
    if (guard > 0) input.consumeEdges();
    syncMeshes(dt);
    audio.tick(Math.abs(speed), inCar && phase === "play", stars > 0 && phase === "play");
    render(dt);
    pushHud(false);
    raf = requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);
  pushHud(true);

  window.__controlsTest = {
    getYaw: () => (inCar && playerCar ? playerCar.yaw : yaw),
    getSpeed: () => (inCar && playerCar ? playerCar.speed : speed),
    setKeys: (codes) => input.setKeys(codes),
    setSteer: (v) => input.setSteer(v),
  };

  return {
    start() {
      audio.unlock();
      if (audio.station === 0) audio.setStation(1);
      phase = "play";
      if (!run && !done.has("furgoneta")) begin("furgoneta");
      pushHud(true);
    },
    togglePause() {
      if (phase === "play") phase = "pause";
      else if (phase === "pause") phase = "play";
      pushHud(true);
    },
    beginMission(id) {
      if (!MISSIONS.some((m) => m.id === id)) return;
      begin(id);
      phase = "play";
      pushHud(true);
    },
    respawn() {
      if (phase === "dead") respawn();
    },
    setStick: (sx, sy) => input.setStick(sx, sy),
    setHold: (name, down) => input.setHold(name, down),
    stop() {
      alive = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      input.dispose();
      audio.dispose();
      renderer.dispose();
      canvas.remove();
      if (window.__controlsTest) delete window.__controlsTest;
    },
  };
}
