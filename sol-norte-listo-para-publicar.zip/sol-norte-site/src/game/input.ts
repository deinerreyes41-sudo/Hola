export type Holds = {
  attack: boolean;
  handbrake: boolean;
  interact: boolean;
  radio: boolean;
  pause: boolean;
};

export type Actions = {
  throttle: number;
  steer: number;
  attack: boolean;
  handbrake: boolean;
  interactEdge: boolean;
  radioEdge: boolean;
  pauseEdge: boolean;
};

const GAME_KEYS = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Space",
  "ShiftLeft",
  "ShiftRight",
  "KeyE",
  "KeyF",
  "KeyR",
  "Escape",
  "KeyP",
]);

function deadzone(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export function createInput(target: HTMLElement) {
  const keys = new Set<string>();
  let forced: Set<string> | null = null;
  let steerLock: number | null = null;
  let stickX = 0;
  let stickY = 0;
  const holds: Holds = {
    attack: false,
    handbrake: false,
    interact: false,
    radio: false,
    pause: false,
  };
  const prev = { interact: false, radio: false, pause: false };
  const actions: Actions = {
    throttle: 0,
    steer: 0,
    attack: false,
    handbrake: false,
    interactEdge: false,
    radioEdge: false,
    pauseEdge: false,
  };

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    keys.add(e.code);
    if (GAME_KEYS.has(e.code)) {
      const el = e.target as HTMLElement | null;
      if (!el?.closest("button, a, input, textarea")) e.preventDefault();
    }
  };
  const onKeyUp = (e: KeyboardEvent) => {
    keys.delete(e.code);
  };
  const clear = () => {
    keys.clear();
    forced = null;
    stickX = 0;
    stickY = 0;
    steerLock = null;
    holds.attack = false;
    holds.handbrake = false;
    holds.interact = false;
    holds.radio = false;
    holds.pause = false;
    prev.interact = false;
    prev.radio = false;
    prev.pause = false;
    actions.throttle = 0;
    actions.steer = 0;
    actions.attack = false;
    actions.handbrake = false;
    consumeEdges();
  };
  const onVis = () => {
    if (document.hidden) clear();
  };
  const onContextMenu = (e: Event) => e.preventDefault();

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", clear);
  document.addEventListener("visibilitychange", onVis);
  target.addEventListener("contextmenu", onContextMenu);

  function sample() {
    const src = forced ?? keys;
    let throttle = 0;
    let steer = 0;
    if (src.has("KeyW") || src.has("ArrowUp")) throttle += 1;
    if (src.has("KeyS") || src.has("ArrowDown")) throttle -= 1;
    // A = left = +steer. yaw += steer * rate turns the nose left under a chase cam.
    if (src.has("KeyA") || src.has("ArrowLeft")) steer += 1;
    if (src.has("KeyD") || src.has("ArrowRight")) steer -= 1;

    const stick = deadzone(stickX, stickY);
    // Stick up is +y (throttle forward). Stick left is -x, which must steer left (+1).
    throttle = Math.max(-1, Math.min(1, throttle + stick.y));
    steer = Math.max(-1, Math.min(1, steer - stick.x));
    if (steerLock !== null) steer = Math.max(-1, Math.min(1, steerLock));

    let padInteract = false;
    let padBrake = false;
    let padAttack = false;
    const pad = navigator.getGamepads?.()[0];
    if (pad && !forced) {
      const ax = deadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
      throttle = Math.max(-1, Math.min(1, throttle - ax.y));
      steer = Math.max(-1, Math.min(1, steer - ax.x));
      padInteract = !!pad.buttons[0]?.pressed;
      padBrake = !!pad.buttons[1]?.pressed;
      padAttack = !!pad.buttons[2]?.pressed;
      if (pad.buttons[7] && pad.buttons[7].value > 0.4) {
        throttle = Math.max(throttle, pad.buttons[7].value);
      }
    }

    const interact = holds.interact || padInteract || src.has("KeyE") || src.has("KeyF");
    const radio = holds.radio || src.has("KeyR");
    const pause = holds.pause || src.has("Escape") || src.has("KeyP");
    const attack = holds.attack || padAttack || src.has("Space");
    const handbrake = holds.handbrake || padBrake || src.has("ShiftLeft") || src.has("ShiftRight");

    if (interact && !prev.interact) actions.interactEdge = true;
    if (radio && !prev.radio) actions.radioEdge = true;
    if (pause && !prev.pause) actions.pauseEdge = true;
    prev.interact = interact;
    prev.radio = radio;
    prev.pause = pause;

    actions.throttle = throttle;
    actions.steer = steer;
    actions.attack = attack;
    actions.handbrake = handbrake;
  }

  function consumeEdges() {
    actions.interactEdge = false;
    actions.radioEdge = false;
    actions.pauseEdge = false;
  }

  return {
    actions,
    sample,
    consumeEdges,
    setStick(x: number, y: number) {
      stickX = x;
      stickY = y;
    },
    setHold(name: keyof Holds, down: boolean) {
      holds[name] = down;
    },
    setKeys(codes: string[]) {
      forced = new Set(codes);
      steerLock = null;
    },
    setSteer(v: number) {
      steerLock = v;
    },
    dispose() {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", clear);
      document.removeEventListener("visibilitychange", onVis);
      target.removeEventListener("contextmenu", onContextMenu);
      clear();
    },
  };
}
