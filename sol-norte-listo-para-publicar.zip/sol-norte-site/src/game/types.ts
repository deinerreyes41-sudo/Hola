export type Phase = "menu" | "play" | "pause" | "dead";

export type Hud = {
  phase: Phase;
  money: number;
  health: number;
  stars: number;
  speedKmh: number;
  inCar: boolean;
  carName: string;
  weapon: string;
  ammo: number;
  pistol: boolean;
  missionTitle: string;
  missionText: string;
  toast: string;
  district: string;
  clock: string;
  radio: string;
  arrow: number;
  dist: number;
  showArrow: boolean;
  deadTitle: string;
  deadText: string;
  done: string[];
  active: string;
  low: boolean;
};

export const INITIAL_HUD: Hud = {
  phase: "menu",
  money: 250,
  health: 100,
  stars: 0,
  speedKmh: 0,
  inCar: false,
  carName: "",
  weapon: "Puños",
  ammo: 0,
  pistol: false,
  missionTitle: "",
  missionText: "Puerto del Sol está despierto.",
  toast: "",
  district: "Parque Central",
  clock: "17:40",
  radio: "Radio off",
  arrow: 0,
  dist: 0,
  showArrow: false,
  deadTitle: "",
  deadText: "",
  done: [],
  active: "",
  low: false,
};

export type MissionId = "furgoneta" | "cobro" | "fuga" | "carrera";

export type MissionMeta = {
  id: MissionId;
  title: string;
  brief: string;
  reward: number;
};

export const MISSIONS: MissionMeta[] = [
  {
    id: "furgoneta",
    title: "La furgoneta",
    brief: "Sube al Toro verde y déjalo en el muelle.",
    reward: 700,
  },
  {
    id: "cobro",
    title: "El cobro",
    brief: "Recoge el paquete en Playa Dorada y vuelve al refugio.",
    reward: 900,
  },
  {
    id: "fuga",
    title: "Fuga limpia",
    brief: "La patrulla sale a buscarte. Llega a Barrio Alto.",
    reward: 1200,
  },
  {
    id: "carrera",
    title: "Contrarreloj",
    brief: "Cinco puntos. Setenta y cinco segundos.",
    reward: 1500,
  },
];

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  setSteer?: (v: number) => void;
  setKeys?: (codes: string[]) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
  }
}
